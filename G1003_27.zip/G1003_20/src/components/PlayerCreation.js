 import { modalUtils } from '../utils/modalUtils.js';

class PlayerCreation {
    constructor({ playerContainer, storage }) {
        console.log('Constructing PlayerCreation with playerContainer:', playerContainer);
        this.playerContainer = playerContainer;
        this.storage = storage;
        this.init();
    }

    init() {
        console.log('Initializing PlayerCreation');
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for PlayerCreation');
        const savePlayerBtn = document.querySelector('.save-player-btn');
        if (savePlayerBtn) {
            savePlayerBtn.addEventListener('click', (e) => {
                console.log('Save Player button clicked');
                this.handleCreatePlayer(e);
            });
        } else {
            console.log('save-player-btn not found in DOM');
        }

        const cancelBtn = document.querySelector('#createPlayerModal .cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                console.log('Cancel button clicked');
                this.closeCreatePlayerModal();
            });
        } else {
            console.log('cancel-btn not found in DOM');
        }
    }

    openCreatePlayerModal() {
        console.log('Opening create player modal');
        modalUtils.showModal('createPlayerModal');
    }

    handleCreatePlayer(e) {
        e.preventDefault();
        const firstName = document.getElementById('firstName').value.trim();
        const lastName = document.getElementById('lastName').value.trim();
        const nickname = document.getElementById('nickname').value.trim();
        const email = document.getElementById('email').value.trim();
        const phoneNumber = document.getElementById('phoneNumber').value.trim();
        const teamSelect = document.getElementById('teamSelect');
        const teamId = teamSelect ? teamSelect.value : '';
        const isCaptain = document.getElementById('isCaptain').checked;

        if (firstName && lastName) {
            const player = {
                id: crypto.randomUUID(),
                firstName,
                lastName,
                nickname,
                email,
                phoneNumber,
                teamId: teamId || null,
                isCaptain: isCaptain || false
            };
            console.log('Creating player:', player);
            this.storage.addPlayer(player);
            this.closeCreatePlayerModal();
            console.log('Player created successfully');
        }
    }

    closeCreatePlayerModal() {
        console.log('Closing create player modal');
        modalUtils.hideModal('createPlayerModal');
        document.getElementById('firstName').value = '';
        document.getElementById('lastName').value = '';
        document.getElementById('nickname').value = '';
        document.getElementById('email').value = '';
        document.getElementById('phoneNumber').value = '';
        const teamSelect = document.getElementById('teamSelect');
        if (teamSelect) {
            teamSelect.selectedIndex = -1;
        }
        document.getElementById('isCaptain').checked = false;
    }
}

export default PlayerCreation;