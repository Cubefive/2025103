 import Storage from '../utils/storage.js';
import PlayerStorage from '../utils/PlayerStorage.js';
import TeamStorage from '../utils/TeamStorage.js';
import TournamentStorage from '../utils/TournamentStorage.js';
import TableDistribution from '../utils/TableDistribution.js';
import PlayerManagement from './PlayerManagement.js';
import TeamManagement from './TeamManagement.js';
import TournamentCheckIn from './TournamentCheckIn.js';

class App {
    constructor(rootElement) {
        console.log('Constructing App with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = null;
        this.playerManagement = null;
        this.teamManagement = null;
        this.tournamentCheckIn = null;
        this.init();
    }

    init() {
        console.log('Initializing App');
        this.render();
        this.initializeComponents();
        this.loadSectionVisibility();
        this.setupToggleListeners();
    }

    initializeComponents() {
        console.log('Initializing components');
        try {
            // Skapa instanser av lagringsklasser
            const playerStorage = new PlayerStorage();
            const teamStorage = new TeamStorage(null); // Tillfälligt null, uppdateras senare
            const tournamentStorage = new TournamentStorage();
            const tableStorage = new TableDistribution({ rootElement: this.rootElement });

            // Skapa Storage med korrekta instanser
            this.storage = new Storage({
                playerStorage,
                teamStorage,
                tournamentStorage,
                tableStorage
            });

            // Uppdatera TeamStorage med korrekt Storage-instans
            teamStorage.storage = this.storage;

            // Skapa komponentinstanser
            this.playerManagement = new PlayerManagement({ rootElement: this.rootElement, storage: this.storage });
            this.teamManagement = new TeamManagement({ rootElement: this.rootElement, storage: this.storage });
            this.tournamentCheckIn = new TournamentCheckIn({ rootElement: this.rootElement, storage: this.storage });
        } catch (error) {
            console.error('Error initializing components:', error);
        }
    }

    loadSectionVisibility() {
        console.log('Loading section visibility from localStorage');
        const visibility = JSON.parse(localStorage.getItem('sectionVisibility')) || {
            playerManagementContainer: false,
            teamManagementContainer: false,
            tournamentManagementContainer: false
        };
        this.toggleSection('playerManagementContainer', visibility.playerManagementContainer);
        this.toggleSection('teamManagementContainer', visibility.teamManagementContainer);
        this.toggleSection('tournamentManagementContainer', visibility.tournamentManagementContainer);
    }

    toggleSection(sectionId, forceState = null) {
        console.log(`Toggling section ${sectionId} to ${forceState === null ? 'toggle' : forceState}`);
        const section = document.getElementById(sectionId);
        if (section) {
            const isVisible = forceState !== null ? forceState : section.style.display !== 'none';
            section.style.display = isVisible ? 'none' : 'block';
            const visibility = JSON.parse(localStorage.getItem('sectionVisibility')) || {};
            visibility[sectionId] = !isVisible;
            localStorage.setItem('sectionVisibility', JSON.stringify(visibility));
            console.log('Section visibility saved:', visibility);
            try {
                if (!isVisible) {
                    if (sectionId === 'playerManagementContainer' && this.playerManagement) {
                        this.playerManagement.render();
                    } else if (sectionId === 'teamManagementContainer' && this.teamManagement) {
                        this.teamManagement.render();
                    } else if (sectionId === 'tournamentManagementContainer' && this.tournamentCheckIn) {
                        this.tournamentCheckIn.render();
                    } else {
                        console.log(`No valid component instance for section ${sectionId}`);
                    }
                }
            } catch (error) {
                console.error(`Error toggling section ${sectionId}:`, error);
            }
        }
    }

    setupToggleListeners() {
        console.log('Setting up toggle listeners for App');
        const toggleButtons = document.querySelectorAll('.toggle-section-btn');
        toggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                console.log('Toggle button clicked for section:', button.dataset.section);
                this.toggleSection(button.dataset.section);
            });
        });
    }

    render() {
        console.log('Rendering App');
        if (this.rootElement) {
            this.rootElement.innerHTML = `
                <h1>Poker Team Tournament Manager</h1>
                <button class="toggle-section-btn btn" data-section="playerManagementContainer">
                    Show Player Management
                </button>
                <div id="playerManagementContainer" style="display: none;"></div>
                <button class="toggle-section-btn btn" data-section="teamManagementContainer">
                    Show Team Management
                </button>
                <div id="teamManagementContainer" style="display: none;"></div>
                <button class="toggle-section-btn btn" data-section="tournamentManagementContainer">
                    Show Tournament Management
                </button>
                <div id="tournamentManagementContainer" style="display: none;"></div>
            `;
            console.log('App render complete, rootElement content:', this.rootElement.innerHTML);
        }
    }
}

export default App;