 const dropdownUtils = {
  createInput: (options) => {
    console.log('Creating input with id:', options.id, 'type:', options.type, 'label:', options.label, 'defaultValue:', options.defaultValue);
    const input = document.createElement('div');
    input.innerHTML = `
      <label for="${options.id}">${options.label}:</label>
      <input type="${options.type}" id="${options.id}" placeholder="${options.placeholder || ''}" value="${options.defaultValue || ''}">
    `;
    console.log('Input created:', input.innerHTML);
    return input.innerHTML;
  },

  createDropdown: (options) => {
    console.log('Creating dropdown with id:', options.id, 'options:', options.options, 'label:', options.label, 'defaultValue:', options.defaultValue, 'multiple:', options.multiple);
    const dropdown = document.createElement('div');
    const multiple = options.multiple ? 'multiple' : '';
    const optionsHtml = options.options ? options.options.map(opt => `<option value="${opt.value || opt}">${opt.label || opt}</option>`).join('') : '';
    const defaultOption = options.multiple ? '<option value="">Select multiple</option>' : '<option value="">Select one</option>';
    dropdown.innerHTML = `
      <label for="${options.id}">${options.label}:</label>
      <select id="${options.id}" ${multiple}>
        ${defaultOption}
        ${optionsHtml}
      </select>
    `;
    console.log('Dropdown created:', dropdown.innerHTML);
    return dropdown.innerHTML;
  }
};

export default dropdownUtils;