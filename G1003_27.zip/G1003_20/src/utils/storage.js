 class Storage {
    constructor(storages) {
        console.log('Constructing Storage with storages:', storages);
        this.storages = storages;
    }

    getPlayerDatabase() {
        console.log('Getting player database');
        return this.storages.playerStorage.getPlayerDatabase();
    }

    addPlayer(player) {
        console.log('Adding player:', player);
        this.storages.playerStorage.addPlayer(player);
    }

    updatePlayer(playerId, player) {
        console.log('Updating player:', playerId, player);
        this.storages.playerStorage.updatePlayer(playerId, player);
    }

    deletePlayer(playerId) {
        console.log('Deleting player:', playerId);
        this.storages.playerStorage.deletePlayer(playerId);
    }

    getTeams() {
        console.log('Getting teams');
        return this.storages.teamStorage.getTeams();
    }

    getTeam(teamId) {
        console.log('Getting team:', teamId);
        return this.storages.teamStorage.getTeam(teamId);
    }

    addTeam(team) {
        console.log('Adding team:', team);
        this.storages.teamStorage.addTeam(team);
    }

    updateTeam(teamId, team) {
        console.log('Updating team:', teamId, team);
        this.storages.teamStorage.updateTeam(teamId, team);
    }

    deleteTeam(teamId) {
        console.log('Deleting team:', teamId);
        this.storages.teamStorage.deleteTeam(teamId);
    }

    getTournamentDatabase() {
        console.log('Getting tournament database');
        return this.storages.tournamentStorage.getTournamentDatabase();
    }

    addTournament(tournament) {
        console.log('Adding tournament:', tournament);
        this.storages.tournamentStorage.addTournament(tournament);
    }

    updateTournament(tournamentId, tournament) {
        console.log('Updating tournament:', tournamentId, tournament);
        this.storages.tournamentStorage.updateTournament(tournamentId, tournament);
    }

    deleteTournament(tournamentId) {
        console.log('Deleting tournament:', tournamentId);
        this.storages.tournamentStorage.deleteTournament(tournamentId);
    }

    getTableDatabase() {
        console.log('Getting table database');
        return this.storages.tableStorage.getTableDatabase();
    }

    addTable(table) {
        console.log('Adding table:', table);
        this.storages.tableStorage.addTable(table);
    }

    updateTable(tableId, table) {
        console.log('Updating table:', tableId, table);
        this.storages.tableStorage.updateTable(tableId, table);
    }

    deleteTable(tableId) {
        console.log('Deleting table:', tableId);
        this.storages.tableStorage.deleteTable(tableId);
    }
}

export default Storage;