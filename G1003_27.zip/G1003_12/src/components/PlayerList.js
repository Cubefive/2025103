 import modalUtils from '../utils/modalUtils.js';
import { renderTeamDropdown, renderTable } from '../utils/uiUtils.js';

class PlayerList {
    constructor({ container, storage }) {
        console.log('Constructing PlayerList with container:', container);
        this.container = container;
        this.storage = storage;
        this.playerSearchInput = null;
        this.teamFilterSelect = null;
        this.init();
    }

    init() {
        console.log('Initializing PlayerList');
        this.renderPlayerTable();
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for PlayerList');
        this.playerSearchInput = document.getElementById('playerSearchInput');
        this.teamFilterSelect = document.getElementById('teamFilterSelect');
        const playerClearIcon = document.querySelector('.player-clear-icon');

        if (this.playerSearchInput) {
            this.playerSearchInput.addEventListener('input', () => {
                console.log('Player search input changed:', this.playerSearchInput.value);
                playerClearIcon.style.display = this.playerSearchInput.value ? 'block' : 'none';
                this.renderPlayerTable();
            });
        } else {
            console.log('playerSearchInput not found in DOM');
        }

        if (playerClearIcon) {
            playerClearIcon.addEventListener('click', () => {
                console.log('Clear player search clicked');
                this.playerSearchInput.value = '';
                playerClearIcon.style.display = 'none';
                this.renderPlayerTable();
            });
        } else {
            console.log('player-clear-icon not found in DOM');
        }

        if (this.teamFilterSelect) {
            this.teamFilterSelect.addEventListener('change', () => {
                console.log('Team filter select changed:', this.teamFilterSelect.value);
                this.renderPlayerTable();
            });
        } else {
            console.log('teamFilterSelect not found in DOM');
        }
    }

    renderPlayerTable() {
        console.log('Rendering player table');
        if (!this.storage || !this.storage.getPlayerDatabase) {
            console.log('Storage or getPlayerDatabase not available');
            return;
        }

        let playerDatabase = this.storage.getPlayerDatabase();
        console.log('Player database:', playerDatabase);

        if (this.playerSearchInput && this.playerSearchInput.value) {
            const searchTerm = this.playerSearchInput.value.toLowerCase();
            console.log('Filtering players by search term:', searchTerm);
            playerDatabase = playerDatabase.filter(player =>
                player.firstName.toLowerCase().includes(searchTerm) ||
                player.lastName.toLowerCase().includes(searchTerm) ||
                player.nickname.toLowerCase().includes(searchTerm)
            );
        }

        if (this.teamFilterSelect && this.teamFilterSelect.value) {
            const teamId = this.teamFilterSelect.value;
            console.log('Filtering players by team:', teamId);
            playerDatabase = playerDatabase.filter(player => player.teamId === teamId);
        }

        console.log('Filtered player database:', playerDatabase);

        const fields = [
            { key: 'firstName', label: 'First Name' },
            { key: 'lastName', label: 'Last Name' },
            { key: 'nickname', label: 'Nickname' },
            { key: 'email', label: 'Email' },
            { key: 'phoneNumber', label: 'Phone Number' },
            {
                key: 'teamId',
                label: 'Team',
                render: (teamId) => {
                    if (this.storage && this.storage.getTeams) {
                        const team = this.storage.getTeams().find(t => t.id === teamId);
                        return team ? team.name : '';
                    }
                    return '';
                }
            },
            {
                key: 'isCaptain',
                label: 'Captain',
                render: (isCaptain) => isCaptain ? 'Yes' : 'No'
            },
            {
                key: 'id',
                label: 'Action',
                render: (id) => `
                    <button class="edit-player-btn btn" data-player-id="${id}">Edit</button>
                    <button class="delete-player-btn btn" data-player-id="${id}">Delete</button>
                `
            }
        ];

        renderTable('player', playerDatabase, fields, 'playerDatabaseTable');

        renderTeamDropdown(this.storage.getTeams(), '', 'teamFilterSelect');

        const editButtons = document.querySelectorAll('.edit-player-btn');
        const deleteButtons = document.querySelectorAll('.delete-player-btn');

        editButtons.forEach(button => {
            button.addEventListener('click', () => {
                console.log('Edit player button clicked:', button.dataset.playerId);
                modalUtils.showModal('editPlayerModal', button.dataset.playerId);
            });
        });

        deleteButtons.forEach(button => {
            button.addEventListener('click', () => {
                console.log('Delete player button clicked:', button.dataset.playerId);
                if (this.storage && this.storage.deletePlayer) {
                    this.storage.deletePlayer(button.dataset.playerId);
                    this.renderPlayerTable();
                }
            });
        });

        console.log('Player table rendered');
    }
}

export default PlayerList;