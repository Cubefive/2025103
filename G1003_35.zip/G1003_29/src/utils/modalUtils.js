 export const modalUtils = {
  showModal: (modalId, data) => {
    console.log('Showing modal:', modalId, 'with data:', data);
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.style.display = 'block';
      modal.classList.add('show');
      modal.querySelector('.modal-content').focus();
      if (data) {
        modal.dataset.modalData = JSON.stringify(data);
      }
      console.log('Modal shown:', modalId);
    } else {
      console.log('Modal not found:', modalId);
    }
  },

  hideModal: (modalId) => {
    console.log('Hiding modal:', modalId);
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.style.display = 'none';
      modal.classList.remove('show');
      delete modal.dataset.modalData;
      console.log('Modal hidden:', modalId);
    } else {
      console.log('Modal not found:', modalId);
    }
  },

  createModalContent: (content) => {
    console.log('Creating modal content:', content);
    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalContent.innerHTML = content;
    console.log('Modal content created:', modalContent.innerHTML);
    return modalContent;
  }
};

console.log('modalUtils exported:', modalUtils);