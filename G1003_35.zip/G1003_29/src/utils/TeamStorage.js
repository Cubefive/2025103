 class TeamStorage {
    constructor(storage) {
        console.log('Constructing TeamStorage');
        this.storage = storage;
        this.teamDatabase = [];
        this.loadTeamDatabase();
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TeamStorage');
        window.addEventListener('playerDatabaseUpdated', () => {
            console.log('playerDatabaseUpdated event received in TeamStorage');
            this.syncTeamsWithPlayers();
        });
    }

    loadTeamDatabase() {
        console.log('Loading teamDatabase');
        const rawTeamDatabase = localStorage.getItem('teamDatabase');
        console.log('Raw teamDatabase from localStorage:', rawTeamDatabase);
        this.teamDatabase = rawTeamDatabase ? JSON.parse(rawTeamDatabase) : [];
        console.log('Loaded teamDatabase:', this.teamDatabase);
    }

    syncTeamsWithPlayers() {
        console.log('Syncing teams with players');
        if (!this.storage || !this.storage.getPlayerDatabase) {
            console.log('storage or getPlayerDatabase not available, skipping teamDatabase sync');
            return;
        }
        const playerDatabase = this.storage.getPlayerDatabase();
        this.teamDatabase.forEach(team => {
            team.playerIds = team.playerIds.filter(id => playerDatabase.find(p => p.id === id));
            if (!team.playerIds.includes(team.captainId)) {
                team.captainId = team.playerIds[0] || null;
            }
        });
        this.saveTeamDatabase();
    }

    saveTeamDatabase() {
        console.log('Saving teamDatabase:', this.teamDatabase);
        localStorage.setItem('teamDatabase', JSON.stringify(this.teamDatabase));
        console.log('teamDatabase saved to localStorage');
        window.dispatchEvent(new Event('teamDatabaseUpdated'));
    }

    getTeams() {
        console.log('Getting team database');
        return this.teamDatabase;
    }

    getTeam(teamId) {
        console.log('Getting team:', teamId);
        return this.teamDatabase.find(team => team.id === teamId);
    }

    addTeam(team) {
        console.log('Adding team:', team);
        this.teamDatabase.push(team);
        this.saveTeamDatabase();
        if (this.storage && this.storage.getPlayerDatabase && this.storage.savePlayerDatabase) {
            const playerDatabase = this.storage.getPlayerDatabase();
            team.playerIds.forEach(playerId => {
                const player = playerDatabase.find(p => p.id === playerId);
                if (player) {
                    player.teamId = team.id;
                    player.isCaptain = playerId === team.captainId;
                }
            });
            this.storage.savePlayerDatabase(playerDatabase);
        }
    }

    updateTeam(teamId, team) {
        console.log('Updating team:', teamId, team);
        const index = this.teamDatabase.findIndex(t => t.id === teamId);
        if (index !== -1) {
            this.teamDatabase[index] = { ...this.teamDatabase[index], ...team };
            this.saveTeamDatabase();
            if (this.storage && this.storage.getPlayerDatabase && this.storage.savePlayerDatabase) {
                const playerDatabase = this.storage.getPlayerDatabase();
                playerDatabase.forEach(player => {
                    if (player.teamId === teamId) {
                        player.isCaptain = player.id === team.captainId;
                    }
                });
                this.storage.savePlayerDatabase(playerDatabase);
            }
        }
    }

    deleteTeam(teamId) {
        console.log('Deleting team:', teamId);
        this.teamDatabase = this.teamDatabase.filter(team => team.id !== teamId);
        this.saveTeamDatabase();
        if (this.storage && this.storage.getPlayerDatabase && this.storage.savePlayerDatabase) {
            const playerDatabase = this.storage.getPlayerDatabase();
            playerDatabase.forEach(player => {
                if (player.teamId === teamId) {
                    player.teamId = null;
                    player.isCaptain = false;
                }
            });
            this.storage.savePlayerDatabase(playerDatabase);
        }
    }
}

export default TeamStorage;