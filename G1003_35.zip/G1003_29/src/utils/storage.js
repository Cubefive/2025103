 import TeamStorage from './TeamStorage.js';
import TournamentStorage from './TournamentStorage.js';
import TableDistribution from './TableDistribution.js';

class Storage {
    constructor() {
        console.log('Constructing Storage with storages:', {
            TeamStorage,
            TournamentStorage,
            TableDistribution
        });
        this.playerDatabase = [];
        this.teamStorage = new TeamStorage(this);
        this.tournamentStorage = new TournamentStorage();
        this.tableDistribution = new TableDistribution();
        this.loadPlayerDatabase();
    }

    loadPlayerDatabase() {
        console.log('Loading playerDatabase');
        const rawPlayerDatabase = localStorage.getItem('playerDatabase');
        console.log('Raw playerDatabase from localStorage:', rawPlayerDatabase);
        this.playerDatabase = rawPlayerDatabase ? JSON.parse(rawPlayerDatabase) : [
            { id: '1', firstName: 'Alice', lastName: 'Adams', nickname: 'Ace', email: 'alice@example.com', phoneNumber: '123-456-7890', teamId: null, isCaptain: false },
            { id: '2', firstName: 'Adam', lastName: 'Allen', nickname: 'AceKicker', email: 'adam@example.com', phoneNumber: '123-456-7891', teamId: null, isCaptain: false },
            // ... (rest of the initial players as before)
        ];
        console.log('Loaded playerDatabase:', this.playerDatabase);
    }

    savePlayerDatabase(playerDatabase) {
        console.log('Saving playerDatabase:', playerDatabase);
        this.playerDatabase = playerDatabase;
        localStorage.setItem('playerDatabase', JSON.stringify(this.playerDatabase));
        console.log('playerDatabase saved to localStorage');
        window.dispatchEvent(new Event('playerDatabaseUpdated'));
    }

    getPlayerDatabase() {
        console.log('Getting player database');
        return this.playerDatabase;
    }

    addPlayer(player) {
        console.log('Adding player:', player);
        this.playerDatabase.push(player);
        this.savePlayerDatabase(this.playerDatabase);
    }

    updatePlayer(playerId, updatedPlayer) {
        console.log('Updating player:', playerId, updatedPlayer);
        const index = this.playerDatabase.findIndex(p => p.id === playerId);
        if (index !== -1) {
            this.playerDatabase[index] = { ...this.playerDatabase[index], ...updatedPlayer };
            this.savePlayerDatabase(this.playerDatabase);
        }
    }

    deletePlayer(playerId) {
        console.log('Deleting player:', playerId);
        this.playerDatabase = this.playerDatabase.filter(p => p.id !== playerId);
        this.savePlayerDatabase(this.playerDatabase);
    }

    getTeams() {
        console.log('Getting teams');
        return this.teamStorage.getTeams();
    }

    addTeam(team) {
        console.log('Adding team:', team);
        this.teamStorage.addTeam(team);
    }

    updateTeam(teamId, team) {
        console.log('Updating team:', teamId, team);
        this.teamStorage.updateTeam(teamId, team);
    }

    deleteTeam(teamId) {
        console.log('Deleting team:', teamId);
        this.teamStorage.deleteTeam(teamId);
    }

    getTeam(teamId) {
        console.log('Getting team:', teamId);
        return this.teamStorage.getTeam(teamId);
    }

    getTournaments() {
        console.log('Getting tournament database');
        return this.tournamentStorage.getTournaments();
    }

    addTournament(tournament) {
        console.log('Adding tournament:', tournament);
        this.tournamentStorage.addTournament(tournament);
    }

    updateTournament(tournamentId, tournament) {
        console.log('Updating tournament:', tournamentId, tournament);
        this.tournamentStorage.updateTournament(tournamentId, tournament);
    }

    deleteTournament(tournamentId) {
        console.log('Deleting tournament:', tournamentId);
        this.tournamentStorage.deleteTournament(tournamentId);
    }

    getTables() {
        console.log('Getting table database');
        return this.tableDistribution.getTables();
    }

    addTable(table) {
        console.log('Adding table:', table);
        this.tableDistribution.addTable(table);
    }

    updateTable(tableId, table) {
        console.log('Updating table:', tableId, table);
        this.tableDistribution.updateTable(tableId, table);
    }

    deleteTable(tableId) {
        console.log('Deleting table:', tableId);
        this.tableDistribution.deleteTable(tableId);
    }
}

export default Storage;