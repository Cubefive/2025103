 export const uiUtils = {
    renderTable: (tableId, data, fields, type) => {
        console.log(`Rendering table for type: ${type}, with data:`, data);
        console.log('Fields for rendering:', fields);
        const table = document.getElementById(tableId);
        if (!table) {
            console.error(`Table with ID ${tableId} not found`);
            return;
        }
        const tbody = table.querySelector('tbody');
        if (!tbody) {
            console.error(`Table body not found for table ${tableId}`);
            return;
        }
        try {
            tbody.innerHTML = '';
            data.forEach(item => {
                const row = document.createElement('tr');
                fields.forEach(field => {
                    const cell = document.createElement('td');
                    if (field.render) {
                        cell.innerHTML = field.render(item[field.key], item);
                    } else {
                        cell.textContent = item[field.key] || '';
                    }
                    row.appendChild(cell);
                });
                tbody.appendChild(row);
            });
            console.log(`Table ${tableId} rendered successfully`);
        } catch (error) {
            console.error(`Error rendering table for ${tableId}:`, error);
        }
    },

    renderTeamDropdown: (items, selectedValue, selectId, multiple = false) => {
        console.log('Rendering team dropdown with items:', items);
        const select = document.getElementById(selectId);
        if (!select) {
            console.error(`Select element with ID ${selectId} not found`);
            return;
        }
        try {
            select.innerHTML = multiple
                ? '<option value="">Select multiple</option>'
                : '<option value="">Select one</option>';
            if (Array.isArray(items)) {
                items.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.id;
                    option.textContent = `${item.firstName || item.name} ${item.lastName || ''}`;
                    if (selectedValue) {
                        if (Array.isArray(selectedValue)) {
                            option.selected = selectedValue.includes(item.id);
                        } else {
                            option.selected = item.id === selectedValue;
                        }
                    }
                    select.appendChild(option);
                });
            } else {
                console.warn(`Items for dropdown ${selectId} is not an array:`, items);
            }
            console.log(`Dropdown ${selectId} rendered successfully`);
        } catch (error) {
            console.error(`Error rendering team dropdown for ${selectId}:`, error);
        }
    },

    renderTeamFilterDropdown: (items, selectedValue, selectId) => {
        console.log('Rendering team filter dropdown with items:', items);
        const select = document.getElementById(selectId);
        if (!select) {
            console.error(`Select element with ID ${selectId} not found`);
            return;
        }
        try {
            select.innerHTML = '<option value="">All Teams</option>';
            if (Array.isArray(items)) {
                items.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.id;
                    option.textContent = item.name;
                    option.selected = item.id === selectedValue;
                    select.appendChild(option);
                });
            } else {
                console.warn(`Items for filter dropdown ${selectId} is not an array:`, items);
            }
            console.log(`Team filter dropdown ${selectId} rendered successfully`);
        } catch (error) {
            console.error(`Error rendering team filter dropdown for ${selectId}:`, error);
        }
    }
};