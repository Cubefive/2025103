 import { modalUtils } from '../utils/modalUtils.js';
import dropdownUtils from '../utils/dropdownUtils.js';
import { uiUtils } from '../utils/uiUtils.js';

class TeamEdit {
    constructor({ rootElement, storage }) {
        console.log('Constructing TeamEdit with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.init();
    }

    init() {
        console.log('Initializing TeamEdit');
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TeamEdit');
        const editTeamBtns = document.querySelectorAll('.edit-team-btn');
        editTeamBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                console.log('Edit team button clicked:', btn.dataset.teamId);
                this.openEditTeamModal(btn.dataset.teamId);
            });
        });

        const saveEditTeamBtn = document.querySelector('.save-edit-team-btn');
        if (saveEditTeamBtn) {
            saveEditTeamBtn.addEventListener('click', (e) => {
                console.log('Save Edit Team button clicked');
                this.handleEditTeam(e);
            });
        } else {
            console.log('save-edit-team-btn not found in DOM');
        }

        const cancelBtn = document.querySelector('#editTeamModal .cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                console.log('Cancel button clicked');
                this.closeEditTeamModal();
            });
        } else {
            console.log('cancel-btn not found in DOM');
        }
    }

    openEditTeamModal(teamId) {
        console.log('Opening edit team modal for teamId:', teamId);
        if (this.storage && this.storage.getTeam) {
            const team = this.storage.getTeam(teamId);
            if (team) {
                document.getElementById('editTeamName').value = team.name;
                const editTeamSelect = document.getElementById('editTeamSelect');
                if (editTeamSelect && this.storage && this.storage.getPlayerDatabase) {
                    const players = this.storage.getPlayerDatabase();
                    console.log('Players for editTeamSelect:', players);
                    uiUtils.renderTeamDropdown(players, team.playerIds, 'editTeamSelect', true);
                    console.log('editTeamSelect populated:', editTeamSelect.innerHTML);
                }
                modalUtils.showModal('editTeamModal', teamId);
            }
        }
    }

    handleEditTeam(e) {
        e.preventDefault();
        const modal = document.getElementById('editTeamModal');
        const teamId = modal.dataset.modalData;
        const teamName = document.getElementById('editTeamName').value.trim();
        const editTeamSelect = document.getElementById('editTeamSelect');
        const selectedPlayers = Array.from(editTeamSelect.selectedOptions).map(option => option.value);

        if (teamName && selectedPlayers.length > 0) {
            const updatedTeam = {
                name: teamName,
                playerIds: selectedPlayers,
                captainId: selectedPlayers[0],
                checkedInTournaments: []
            };
            console.log('Updating team:', updatedTeam);
            this.storage.updateTeam(teamId, updatedTeam);
            this.closeEditTeamModal();
            console.log('Team updated successfully');
        }
    }

    closeEditTeamModal() {
        console.log('Closing edit team modal');
        modalUtils.hideModal('editTeamModal');
        document.getElementById('editTeamName').value = '';
        const editTeamSelect = document.getElementById('editTeamSelect');
        if (editTeamSelect) {
            editTeamSelect.selectedIndex = -1;
        }
    }
}

export default TeamEdit;