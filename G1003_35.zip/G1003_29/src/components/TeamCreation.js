 import { modalUtils } from '../utils/modalUtils.js';
import { uiUtils } from '../utils/uiUtils.js';
import { v4 as uuidv4 } from 'uuid';

class TeamCreation {
    constructor({ rootElement, storage, props }) {
        console.log('Constructing TeamCreation with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.props = props || {};
        this.init();
    }

    init() {
        console.log('Initializing TeamCreation');
        this.render();
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TeamCreation');
        const createTeamButton = this.rootElement.querySelector('.create-team-btn');
        const saveTeamButton = this.rootElement.querySelector('.save-team-btn');
        const cancelButton = this.rootElement.querySelector('.cancel-btn');

        if (createTeamButton) {
            createTeamButton.addEventListener('click', () => {
                console.log('Create Team button clicked');
                this.openCreateTeamModal();
            });
        }

        if (saveTeamButton) {
            saveTeamButton.addEventListener('click', () => {
                console.log('Save Team button clicked');
                this.handleCreateTeam();
            });
        }

        if (cancelButton) {
            cancelButton.addEventListener('click', () => {
                console.log('Cancel button clicked');
                this.closeCreateTeamModal();
            });
        }
    }

    openCreateTeamModal() {
        console.log('Opening create team modal');
        this.render();
        this.populateTeamSelect();
        modalUtils.showModal('createTeamModal');
    }

    populateTeamSelect() {
        console.log('Populating team select dropdown');
        if (!this.storage || !this.storage.getPlayerDatabase) {
            console.log('Storage or getPlayerDatabase not available');
            return;
        }
        const players = this.storage.getPlayerDatabase();
        console.log('Players for team select:', players);
        uiUtils.renderTeamDropdown(players, '', 'teamSelect', true);
        console.log('Team select populated:', document.getElementById('teamSelect').innerHTML);
    }

    handleCreateTeam() {
        console.log('Handling create team');
        const teamNameInput = document.getElementById('teamName');
        const teamSelect = document.getElementById('teamSelect');

        if (!teamNameInput || !teamSelect) {
            console.log('Team name input or team select not found');
            return;
        }

        const teamName = teamNameInput.value;
        const playerIds = Array.from(teamSelect.selectedOptions).map(option => option.value);

        if (!teamName || playerIds.length === 0) {
            console.log('Team name or players not provided');
            return;
        }

        const team = {
            id: uuidv4(),
            name: teamName,
            playerIds,
            captainId: playerIds[0] || '',
            checkedInTournaments: []
        };

        console.log('Creating team:', team);
        this.storage.addTeam(team);
        teamNameInput.value = '';
        teamSelect.value = '';
        modalUtils.hideModal('createTeamModal');
        if (this.props.onTeamCreated) {
            console.log('Calling onTeamCreated callback');
            this.props.onTeamCreated();
        }
    }

    closeCreateTeamModal() {
        console.log('Closing create team modal');
        const teamNameInput = document.getElementById('teamName');
        const teamSelect = document.getElementById('teamSelect');
        if (teamNameInput) teamNameInput.value = '';
        if (teamSelect) teamSelect.value = '';
        modalUtils.hideModal('createTeamModal');
    }

    render() {
        console.log('TeamCreation rendering');
        const createTeamModal = this.rootElement.querySelector('#createTeamModal');
        if (createTeamModal) {
            createTeamModal.innerHTML = `
                <div class="modal-content">
                    <label for="teamName">Team Name:</label>
                    <input type="text" id="teamName" placeholder="Enter team name">
                    <label for="teamSelect">Select Players:</label>
                    <select id="teamSelect" multiple>
                        <option value="">Select multiple</option>
                    </select>
                    <div class="modal-actions">
                        <button class="save-team-btn btn">Save</button>
                        <button class="cancel-btn btn">Cancel</button>
                    </div>
                </div>
            `;
        }
    }
}

export default TeamCreation;