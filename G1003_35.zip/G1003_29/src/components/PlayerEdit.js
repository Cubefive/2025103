 import { modalUtils } from '../utils/modalUtils.js';

class PlayerEdit {
    constructor({ playerContainer, storage }) {
        console.log('Constructing PlayerEdit with playerContainer:', playerContainer);
        this.playerContainer = playerContainer;
        this.storage = storage;
        this.init();
    }

    init() {
        console.log('Initializing PlayerEdit');
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for PlayerEdit');
        const saveEditPlayerBtn = document.querySelector('.save-edit-player-btn');
        if (saveEditPlayerBtn) {
            saveEditPlayerBtn.addEventListener('click', (e) => {
                console.log('Save Edit Player button clicked');
                this.handleEditPlayer(e);
            });
        } else {
            console.log('save-edit-player-btn not found in DOM');
        }

        const cancelBtn = document.querySelector('#editPlayerModal .cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                console.log('Cancel button clicked');
                this.closeEditPlayerModal();
            });
        } else {
            console.log('cancel-btn not found in DOM');
        }
    }

    openEditPlayerModal(playerId) {
        console.log('Opening edit player modal for playerId:', playerId);
        if (this.storage && this.storage.getPlayerDatabase) {
            const player = this.storage.getPlayerDatabase().find(p => p.id === playerId);
            if (player) {
                document.getElementById('editFirstName').value = player.firstName;
                document.getElementById('editLastName').value = player.lastName;
                document.getElementById('editNickname').value = player.nickname;
                document.getElementById('editEmail').value = player.email;
                document.getElementById('editPhoneNumber').value = player.phoneNumber;
                const editTeamSelect = document.getElementById('editTeamSelect');
                if (editTeamSelect) {
                    editTeamSelect.value = player.teamId || '';
                }
                document.getElementById('editIsCaptain').checked = player.isCaptain;
                modalUtils.showModal('editPlayerModal', playerId);
            }
        }
    }

    handleEditPlayer(e) {
        e.preventDefault();
        const modal = document.getElementById('editPlayerModal');
        const playerId = modal.dataset.modalData;
        const firstName = document.getElementById('editFirstName').value.trim();
        const lastName = document.getElementById('editLastName').value.trim();
        const nickname = document.getElementById('editNickname').value.trim();
        const email = document.getElementById('editEmail').value.trim();
        const phoneNumber = document.getElementById('editPhoneNumber').value.trim();
        const teamSelect = document.getElementById('editTeamSelect');
        const teamId = teamSelect ? teamSelect.value : '';
        const isCaptain = document.getElementById('editIsCaptain').checked;

        if (firstName && lastName) {
            const player = {
                id: playerId,
                firstName,
                lastName,
                nickname,
                email,
                phoneNumber,
                teamId: teamId || null,
                isCaptain
            };
            console.log('Updating player:', player);
            this.storage.updatePlayer(playerId, player);
            this.closeEditPlayerModal();
            console.log('Player updated successfully');
        }
    }

    closeEditPlayerModal() {
        console.log('Closing edit player modal');
        modalUtils.hideModal('editPlayerModal');
        document.getElementById('editFirstName').value = '';
        document.getElementById('editLastName').value = '';
        document.getElementById('editNickname').value = '';
        document.getElementById('editEmail').value = '';
        document.getElementById('editPhoneNumber').value = '';
        const editTeamSelect = document.getElementById('editTeamSelect');
        if (editTeamSelect) {
            editTeamSelect.selectedIndex = -1;
        }
        document.getElementById('editIsCaptain').checked = false;
    }
}

export default PlayerEdit;