 import { modalUtils } from '../utils/modalUtils.js';
import { uiUtils } from '../utils/uiUtils.js';

class TeamCreation {
    constructor({ rootElement, storage, props }) {
        console.log('Constructing TeamCreation with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.props = props || {};
        this.init();
    }

    // Simple UUID generator without external dependency
    generateUUID() {
        console.log('Generating UUID');
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    init() {
        console.log('Initializing TeamCreation');
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TeamCreation');
        try {
            const createTeamButton = this.rootElement.querySelector('.create-team-btn');
            const saveTeamButton = this.rootElement.querySelector('.save-team-btn');
            const cancelButton = this.rootElement.querySelector('.cancel-btn');

            if (createTeamButton) {
                createTeamButton.addEventListener('click', () => {
                    console.log('Create Team button clicked');
                    this.openCreateTeamModal();
                });
            } else {
                console.error('Create Team button not found');
            }

            if (saveTeamButton) {
                saveTeamButton.addEventListener('click', () => {
                    console.log('Save Team button clicked');
                    try {
                        this.handleCreateTeam();
                    } catch (error) {
                        console.error('Error in handleCreateTeam:', error);
                    }
                });
            } else {
                console.error('Save Team button not found');
            }

            if (cancelButton) {
                cancelButton.addEventListener('click', () => {
                    console.log('Cancel button clicked');
                    try {
                        this.closeCreateTeamModal();
                    } catch (error) {
                        console.error('Error in closeCreateTeamModal:', error);
                    }
                });
            } else {
                console.error('Cancel button not found');
            }
        } catch (error) {
            console.error('Error setting up event listeners for TeamCreation:', error);
        }
    }

    openCreateTeamModal() {
        console.log('Opening create team modal');
        try {
            this.render(); // Render modal content first
            modalUtils.showModal('createTeamModal');
            setTimeout(() => {
                try {
                    this.populateTeamSelect();
                } catch (error) {
                    console.error('Error in populateTeamSelect:', error);
                }
            }, 500); // Delay to ensure modal is fully rendered
        } catch (error) {
            console.error('Error opening create team modal:', error);
        }
    }

    populateTeamSelect() {
        console.log('Populating team select dropdown');
        const teamSelect = document.getElementById('teamSelect');
        if (!teamSelect) {
            console.error('teamSelect element not found');
            return;
        }
        if (!this.storage || !this.storage.getPlayerDatabase) {
            console.error('Storage or getPlayerDatabase not available');
            return;
        }
        const players = this.storage.getPlayerDatabase();
        console.log('Players for team select:', players);
        uiUtils.renderTeamDropdown(players, '', 'teamSelect', true);
        console.log('Team select populated:', teamSelect.innerHTML);
    }

    handleCreateTeam() {
        console.log('Handling create team');
        const teamNameInput = document.getElementById('teamName');
        const teamSelect = document.getElementById('teamSelect');

        if (!teamNameInput || !teamSelect) {
            console.error('Team name input or team select not found');
            return;
        }

        const teamName = teamNameInput.value;
        const playerIds = Array.from(teamSelect.selectedOptions).map(option => option.value);

        if (!teamName || playerIds.length === 0) {
            console.error('Team name or players not provided');
            alert('Please provide a team name and select at least one player.');
            return;
        }

        const team = {
            id: this.generateUUID(),
            name: teamName,
            playerIds,
            captainId: playerIds[0] || '',
            checkedInTournaments: []
        };

        console.log('Creating team:', team);
        try {
            this.storage.addTeam(team);
            console.log('Team added successfully');
            teamNameInput.value = '';
            teamSelect.value = '';
            modalUtils.hideModal('createTeamModal');
            if (this.props.onTeamCreated) {
                console.log('Calling onTeamCreated callback');
                this.props.onTeamCreated();
            }
        } catch (error) {
            console.error('Error adding team:', error);
        }
    }

    closeCreateTeamModal() {
        console.log('Closing create team modal');
        try {
            const teamNameInput = document.getElementById('teamName');
            const teamSelect = document.getElementById('teamSelect');
            if (teamNameInput) teamNameInput.value = '';
            if (teamSelect) teamSelect.value = '';
            modalUtils.hideModal('createTeamModal');
        } catch (error) {
            console.error('Error closing create team modal:', error);
        }
    }

    render() {
        console.log('TeamCreation rendering');
        const createTeamModal = this.rootElement.querySelector('#createTeamModal');
        if (createTeamModal) {
            createTeamModal.innerHTML = `
                <div class="modal-content">
                    <label for="teamName">Team Name:</label>
                    <input type="text" id="teamName" placeholder="Enter team name">
                    <label for="teamSelect">Select Players:</label>
                    <select id="teamSelect" multiple>
                        <option value="">Select multiple</option>
                    </select>
                    <div class="modal-actions">
                        <button class="save-team-btn btn">Save</button>
                        <button class="cancel-btn btn">Cancel</button>
                    </div>
                </div>
            `;
            console.log('createTeamModal content updated:', createTeamModal.innerHTML);
        } else {
            console.error('createTeamModal element not found');
        }
    }
}

export default TeamCreation;