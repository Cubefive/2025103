 export const modalUtils = {
    showModal(modalId, data) {
        console.log(`Showing modal: ${modalId} with data:`, data);
        try {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'block';
                console.log(`Modal shown: ${modalId}`);
            } else {
                console.error(`Modal with ID ${modalId} not found`);
            }
        } catch (error) {
            console.error(`Error showing modal ${modalId}:`, error);
        }
    },

    hideModal(modalId) {
        console.log(`Hiding modal: ${modalId}`);
        try {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = 'none';
                console.log(`Modal hidden: ${modalId}`);
            } else {
                console.error(`Modal with ID ${modalId} not found`);
            }
        } catch (error) {
            console.error(`Error hiding modal ${modalId}:`, error);
        }
    }
};

console.log('modalUtils exported:', modalUtils);