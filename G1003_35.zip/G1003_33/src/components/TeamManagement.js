 import { modalUtils } from '../utils/modalUtils.js';
import dropdownUtils from '../utils/dropdownUtils.js';
import { uiUtils } from '../utils/uiUtils.js';
import TeamCreation from './TeamCreation.js';
import TeamEdit from './TeamEdit.js';
import TeamCaptainEdit from './TeamCaptainEdit.js';

class TeamManagement {
    constructor({ rootElement, storage }) {
        console.log('Constructing TeamManagement with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.teamCreation = null;
        this.teamEdit = null;
        this.teamCaptainEdit = null;
        this.init();
    }

    init() {
        console.log('Initializing TeamManagement');
        this.render();
        setTimeout(() => {
            this.refreshTeamTable();
        }, 100); // Delay to ensure DOM is ready
        this.setupEventListeners();
    }

    refreshTeamTable() {
        console.log('Refreshing team table');
        const teamTable = document.getElementById('teamTable');
        if (!teamTable) {
            console.log('teamTable element not found');
            return;
        }
        if (!this.storage || !this.storage.getTeams || !this.storage.getPlayerDatabase) {
            console.log('Storage or getTeams/getPlayerDatabase not available');
            return;
        }
        const teamDatabase = this.storage.getTeams();
        const playerDatabase = this.storage.getPlayerDatabase();
        console.log('Team database:', teamDatabase);
        console.log('Player database for team table:', playerDatabase);

        const fields = [
            { key: 'name', label: 'Team Name' },
            {
                key: 'playerIds',
                label: 'Players',
                render: (playerIds) => {
                    return playerIds
                        .map(id => {
                            const player = playerDatabase.find(p => p.id === id);
                            return player ? `${player.firstName} ${player.lastName}` : 'Unknown';
                        })
                        .join(', ');
                }
            },
            {
                key: 'captainId',
                label: 'Captain',
                render: (captainId) => {
                    const captain = playerDatabase.find(p => p.id === captainId);
                    return captain ? `${captain.firstName} ${player.lastName}` : 'Unknown';
                }
            },
            {
                key: 'id',
                label: 'Actions',
                render: (id) => `
                    <button class="edit-team-btn btn" data-team-id="${id}">Edit</button>
                    <button class="edit-captain-btn btn" data-team-id="${id}">Edit Captain</button>
                    <button class="delete-team-btn btn" data-team-id="${id}">Delete</button>
                `
            }
        ];

        uiUtils.renderTable('teamTable', teamDatabase, fields, 'team');
        console.log('Team table HTML:', teamTable.innerHTML);
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TeamManagement');
        const deleteTeamButtons = this.rootElement.querySelectorAll('.delete-team-btn');
        deleteTeamButtons.forEach(button => {
            button.addEventListener('click', () => {
                console.log('Delete team button clicked:', button.dataset.teamId);
                if (this.storage && this.storage.deleteTeam) {
                    this.storage.deleteTeam(button.dataset.teamId);
                    this.refreshTeamTable();
                }
            });
        });

        console.log(`Event listeners set up for ${deleteTeamButtons.length} delete buttons`);
    }

    render() {
        console.log('TeamManagement rendering');
        const teamManagementContainer = document.getElementById('teamManagementContainer');
        if (teamManagementContainer) {
            teamManagementContainer.innerHTML = `
                <div>
                    <h2>Team Management</h2>
                    <button class="create-team-btn btn">Create Team</button>
                    <div id="createTeamModal" class="modal">
                        <div class="modal-content">
                            ${dropdownUtils.createInput({ id: 'teamName', type: 'text', label: 'Team Name', placeholder: 'Enter team name' })}
                            ${dropdownUtils.createDropdown({ id: 'teamSelect', label: 'Select Players', multiple: true })}
                            <div class="modal-actions">
                                <button class="save-team-btn btn">Save</button>
                                <button class="cancel-btn btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                    <div id="editTeamModal" class="modal">
                        <div class="modal-content">
                            ${dropdownUtils.createInput({ id: 'editTeamName', type: 'text', label: 'Team Name', placeholder: 'Enter team name' })}
                            ${dropdownUtils.createDropdown({ id: 'editTeamSelect', label: 'Select Players', multiple: true })}
                            <div class="modal-actions">
                                <button class="save-edit-team-btn btn">Save</button>
                                <button class="cancel-btn btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                    <div id="editCaptainModal" class="modal">
                        <div class="modal-content">
                            ${dropdownUtils.createDropdown({ id: 'editCaptainSelect', label: 'Select Captain' })}
                            <div class="modal-actions">
                                <button class="save-captain-btn btn">Save</button>
                                <button class="cancel-btn btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                    <table id="teamTable">
                        <thead>
                            <tr>
                                <th>Team Name</th>
                                <th>Players</th>
                                <th>Captain</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            `;
            console.log('TeamManagement content rendered in teamManagementContainer:', teamManagementContainer.innerHTML);

            try {
                this.teamCreation = new TeamCreation({
                    rootElement: teamManagementContainer,
                    storage: this.storage,
                    props: { onTeamCreated: () => this.refreshTeamTable() }
                });
            } catch (error) {
                console.error('Error initializing TeamCreation:', error);
            }
            try {
                this.teamEdit = new TeamEdit({ rootElement: teamManagementContainer, storage: this.storage });
            } catch (error) {
                console.error('Error initializing TeamEdit:', error);
            }
            try {
                this.teamCaptainEdit = new TeamCaptainEdit({ rootElement: teamManagementContainer, storage: this.storage });
            } catch (error) {
                console.error('Error initializing TeamCaptainEdit:', error);
            }
        }
    }
}

export default TeamManagement;