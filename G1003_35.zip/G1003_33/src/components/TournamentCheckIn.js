 import { modalUtils } from '../utils/modalUtils.js';
import dropdownUtils from '../utils/dropdownUtils.js';
import { uiUtils } from '../utils/uiUtils.js';

class TournamentCheckIn {
    constructor({ rootElement, storage }) {
        console.log('Constructing TournamentCheckIn with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.init();
    }

    // Simple UUID generator without external dependency
    generateUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    init() {
        console.log('Initializing TournamentCheckIn');
        this.render();
        setTimeout(() => {
            this.refreshTournamentSelect();
        }, 100); // Delay to ensure DOM is ready
        this.setupEventListeners();
        this.loadSectionVisibility();
    }

    loadSectionVisibility() {
        console.log('Loading tournament section visibility from localStorage');
        const visibility = JSON.parse(localStorage.getItem('tournamentSectionVisibility') || '{}');
        console.log('Tournament section visibility:', visibility);
        ['checkInTeamsContainer', 'tableDistributionContainer'].forEach(section => {
            const container = this.rootElement.querySelector(`#${section}`);
            if (container) {
                container.style.display = visibility[section] ? 'block' : 'none';
            }
        });
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TournamentCheckIn');
        const tournamentSelect = this.rootElement.querySelector('#tournamentSelect');
        const createTournamentButton = this.rootElement.querySelector('.create-tournament-open-btn');
        const editTournamentButton = this.rootElement.querySelector('.edit-tournament-open-btn');
        const deleteTournamentButton = this.rootElement.querySelector('.delete-tournament-btn');
        const saveTournamentButton = this.rootElement.querySelector('.create-tournament-btn');
        const saveEditTournamentButton = this.rootElement.querySelector('.edit-tournament-btn');
        const saveAsTournamentButton = this.rootElement.querySelector('.save-as-tournament-btn');
        const cancelButtons = this.rootElement.querySelectorAll('.cancel-btn');
        const toggleButtons = this.rootElement.querySelectorAll('.toggle-tournament-btn');

        if (tournamentSelect) {
            tournamentSelect.addEventListener('change', () => {
                console.log('Tournament select changed:', tournamentSelect.value);
                this.refreshTournamentDetails(tournamentSelect.value);
            });
        }

        if (createTournamentButton) {
            createTournamentButton.addEventListener('click', () => {
                console.log('Create Tournament button clicked');
                modalUtils.showModal('createTournamentModal');
            });
        }

        if (editTournamentButton) {
            editTournamentButton.addEventListener('click', () => {
                console.log('Edit Tournament button clicked');
                const selectedTournamentId = tournamentSelect ? tournamentSelect.value : '';
                if (selectedTournamentId) {
                    this.populateEditTournamentModal(selectedTournamentId);
                    modalUtils.showModal('editTournamentModal');
                }
            });
        }

        if (deleteTournamentButton) {
            deleteTournamentButton.addEventListener('click', () => {
                console.log('Delete Tournament button clicked');
                const selectedTournamentId = tournamentSelect ? tournamentSelect.value : '';
                if (selectedTournamentId) {
                    console.log('Deleting tournament:', selectedTournamentId);
                    this.storage.deleteTournament(selectedTournamentId);
                    this.refreshTournamentSelect();
                }
            });
        }

        if (saveTournamentButton) {
            saveTournamentButton.addEventListener('click', () => {
                console.log('Save Tournament button clicked');
                this.handleCreateTournament();
            });
        }

        if (saveEditTournamentButton) {
            saveEditTournamentButton.addEventListener('click', () => {
                console.log('Save Edit Tournament button clicked');
                this.handleEditTournament();
            });
        }

        if (saveAsTournamentButton) {
            saveAsTournamentButton.addEventListener('click', () => {
                console.log('Save As Tournament button clicked');
                this.handleSaveAsTournament();
            });
        }

        cancelButtons.forEach(button => {
            button.addEventListener('click', () => {
                console.log('Cancel button clicked');
                modalUtils.hideModal(button.closest('.modal').id);
            });
        });

        toggleButtons.forEach(button => {
            button.addEventListener('click', () => {
                const section = button.dataset.section;
                console.log(`Toggling tournament section ${section}`);
                const container = this.rootElement.querySelector(`#${section}`);
                if (container) {
                    container.style.display = container.style.display === 'none' ? 'block' : 'none';
                    const visibility = JSON.parse(localStorage.getItem('tournamentSectionVisibility') || '{}');
                    visibility[section] = container.style.display === 'block';
                    localStorage.setItem('tournamentSectionVisibility', JSON.stringify(visibility));
                }
            });
        });

        window.addEventListener('teamDatabaseUpdated', () => {
            console.log('teamDatabaseUpdated event received in TournamentCheckIn');
            const selectedTournamentId = tournamentSelect ? tournamentSelect.value : '';
            if (selectedTournamentId) {
                this.refreshCheckInTeams(selectedTournamentId);
            }
        });
    }

    refreshTournamentSelect() {
        console.log('Refreshing tournament select');
        const tournamentSelect = document.getElementById('tournamentSelect');
        if (!tournamentSelect) {
            console.log('tournamentSelect element not found');
            return;
        }
        if (!this.storage || !this.storage.getTournaments) {
            console.log('Storage or getTournaments not available');
            return;
        }
        const tournaments = this.storage.getTournaments();
        console.log('Tournaments in select:', tournaments);
        uiUtils.renderTournamentDropdown(tournaments, '', 'tournamentSelect');
        console.log('Tournament select updated:', tournamentSelect.innerHTML);
    }

    refreshTournamentDetails(tournamentId) {
        console.log('Refreshing tournament details for id:', tournamentId);
        if (!tournamentId) return;
        const tournaments = this.storage.getTournaments();
        const tournament = tournaments.find(t => t.id === tournamentId);
        const tournamentDetails = this.rootElement.querySelector('#tournamentDetails');
        if (tournament && tournamentDetails) {
            tournamentDetails.innerHTML = `
                <h3>${tournament.name}</h3>
                <p>Date: ${tournament.date}</p>
                <p>Max Teams: ${tournament.maxTeams}</p>
                <p>Stacks per Team: ${tournament.stacksPerTeam}</p>
                <p>Location: ${tournament.location}</p>
                <p>Start Time: ${tournament.startTime}</p>
                <p>Type: ${tournament.type}</p>
                <p>Max Tables: ${tournament.maxTables}</p>
                <p>Stack Size: ${tournament.stackSize}</p>
                <p>Status: ${tournament.status}</p>
                <p>Organizer: ${tournament.organizer}</p>
                <p>Max Seats per Table: ${tournament.maxSeatsPerTable}</p>
                <p>Allocation Mode: ${tournament.allocationMode}</p>
            `;
            this.refreshCheckInTeams(tournamentId);
        }
    }

    refreshCheckInTeams(tournamentId) {
        console.log('Refreshing check-in teams for tournament id:', tournamentId);
        const teams = this.storage.getTeams();
        const tournament = this.storage.getTournaments().find(t => t.id === tournamentId);
        const checkInTeamsList = this.rootElement.querySelector('#checkInTeamsList');
        const playerDatabase = this.storage.getPlayerDatabase();
        if (tournament && checkInTeamsList) {
            checkInTeamsList.innerHTML = tournament.checkedInTeams.map(teamId => {
                const team = teams.find(t => t.id === teamId);
                if (!team) return '';
                const playerNames = team.playerIds
                    .map(id => {
                        const player = playerDatabase.find(p => p.id === id);
                        return player ? `${player.firstName} ${player.lastName}` : 'Unknown';
                    })
                    .join(', ');
                return `
                    <li>
                        ${team.name} (${playerNames})
                        <button class="check-in-team-btn btn" data-team-id="${team.id}" data-checked="${tournament.checkedInTeams.includes(team.id)}">
                            ${tournament.checkedInTeams.includes(team.id) ? 'Check Out' : 'Check In'}
                        </button>
                    </li>
                `;
            }).join('');
            this.setupCheckInTeamListeners(tournamentId);
        }
    }

    setupCheckInTeamListeners(tournamentId) {
        console.log('Setting up check-in team listeners for tournament id:', tournamentId);
        const checkInTeamButtons = this.rootElement.querySelectorAll('.check-in-team-btn');
        checkInTeamButtons.forEach(button => {
            button.addEventListener('click', () => {
                const teamId = button.dataset.teamId;
                const isChecked = button.dataset.checked === 'true';
                console.log(`Check-in team button clicked for team ${teamId}, checked: ${isChecked}`);
                const tournament = this.storage.getTournaments().find(t => t.id === tournamentId);
                if (tournament) {
                    if (isChecked) {
                        tournament.checkedInTeams = tournament.checkedInTeams.filter(id => id !== teamId);
                    } else {
                        tournament.checkedInTeams.push(teamId);
                    }
                    this.storage.updateTournament(tournamentId, tournament);
                    this.refreshCheckInTeams(tournamentId);
                }
            });
        });
    }

    populateEditTournamentModal(tournamentId) {
        console.log('Populating edit tournament modal for id:', tournamentId);
        const tournament = this.storage.getTournaments().find(t => t.id === tournamentId);
        if (tournament) {
            document.getElementById('editTournamentName').value = tournament.name;
            document.getElementById('editTournamentDate').value = tournament.date;
            document.getElementById('editTournamentMaxTeams').value = tournament.maxTeams;
            document.getElementById('editTournamentStacksPerTeam').value = tournament.stacksPerTeam;
            document.getElementById('editTournamentLocation').value = tournament.location;
            document.getElementById('editTournamentStartTime').value = tournament.startTime;
            document.getElementById('editTournamentType').value = tournament.type;
            document.getElementById('editTournamentMaxTables').value = tournament.maxTables;
            document.getElementById('editTournamentStackSize').value = tournament.stackSize;
            document.getElementById('editTournamentStatus').value = tournament.status;
            document.getElementById('editTournamentOrganizer').value = tournament.organizer;
            document.getElementById('editTournamentMaxSeatsPerTable').value = tournament.maxSeatsPerTable;
            document.getElementById('editTournamentAllocationMode').value = tournament.allocationMode;
        }
    }

    handleCreateTournament() {
        console.log('Handling create tournament');
        const tournament = {
            id: this.generateUUID(),
            name: document.getElementById('tournamentName').value,
            date: document.getElementById('tournamentDate').value,
            maxTeams: parseInt(document.getElementById('tournamentMaxTeams').value) || 0,
            stacksPerTeam: parseInt(document.getElementById('tournamentStacksPerTeam').value) || 0,
            location: document.getElementById('tournamentLocation').value,
            startTime: document.getElementById('tournamentStartTime').value,
            type: document.getElementById('tournamentType').value,
            maxTables: parseInt(document.getElementById('tournamentMaxTables').value) || 0,
            stackSize: parseInt(document.getElementById('tournamentStackSize').value) || 0,
            status: document.getElementById('tournamentStatus').value,
            organizer: document.getElementById('tournamentOrganizer').value,
            maxSeatsPerTable: parseInt(document.getElementById('tournamentMaxSeatsPerTable').value) || 9,
            allocationMode: document.getElementById('tournamentAllocationMode').value,
            checkedInTeams: [],
            startTimestamp: null
        };
        console.log('Creating tournament:', tournament);
        this.storage.addTournament(tournament);
        modalUtils.hideModal('createTournamentModal');
        this.refreshTournamentSelect();
    }

    handleEditTournament() {
        console.log('Handling edit tournament');
        const tournamentSelect = this.rootElement.querySelector('#tournamentSelect');
        const tournamentId = tournamentSelect ? tournamentSelect.value : '';
        if (tournamentId) {
            const tournament = {
                name: document.getElementById('editTournamentName').value,
                date: document.getElementById('editTournamentDate').value,
                maxTeams: parseInt(document.getElementById('editTournamentMaxTeams').value) || 0,
                stacksPerTeam: parseInt(document.getElementById('editTournamentStacksPerTeam').value) || 0,
                location: document.getElementById('editTournamentLocation').value,
                startTime: document.getElementById('editTournamentStartTime').value,
                type: document.getElementById('editTournamentType').value,
                maxTables: parseInt(document.getElementById('editTournamentMaxTables').value) || 0,
                stackSize: parseInt(document.getElementById('editTournamentStackSize').value) || 0,
                status: document.getElementById('editTournamentStatus').value,
                organizer: document.getElementById('editTournamentOrganizer').value,
                maxSeatsPerTable: parseInt(document.getElementById('editTournamentMaxSeatsPerTable').value) || 9,
                allocationMode: document.getElementById('editTournamentAllocationMode').value
            };
            console.log('Updating tournament:', tournamentId, tournament);
            this.storage.updateTournament(tournamentId, tournament);
            modalUtils.hideModal('editTournamentModal');
            this.refreshTournamentSelect();
        }
    }

    handleSaveAsTournament() {
        console.log('Handling save as tournament');
        const tournament = {
            id: this.generateUUID(),
            name: document.getElementById('editTournamentName').value,
            date: document.getElementById('editTournamentDate').value,
            maxTeams: parseInt(document.getElementById('editTournamentMaxTeams').value) || 0,
            stacksPerTeam: parseInt(document.getElementById('editTournamentStacksPerTeam').value) || 0,
            location: document.getElementById('editTournamentLocation').value,
            startTime: document.getElementById('editTournamentStartTime').value,
            type: document.getElementById('editTournamentType').value,
            maxTables: parseInt(document.getElementById('editTournamentMaxTables').value) || 0,
            stackSize: parseInt(document.getElementById('editTournamentStackSize').value) || 0,
            status: document.getElementById('editTournamentStatus').value,
            organizer: document.getElementById('editTournamentOrganizer').value,
            maxSeatsPerTable: parseInt(document.getElementById('editTournamentMaxSeatsPerTable').value) || 9,
            allocationMode: document.getElementById('editTournamentAllocationMode').value,
            checkedInTeams: [],
            startTimestamp: null
        };
        console.log('Creating new tournament:', tournament);
        this.storage.addTournament(tournament);
        modalUtils.hideModal('editTournamentModal');
        this.refreshTournamentSelect();
    }

    render() {
        console.log('TournamentCheckIn rendering');
        const tournamentManagementContainer = document.getElementById('tournamentManagementContainer');
        if (tournamentManagementContainer) {
            tournamentManagementContainer.innerHTML = `
                <div>
                    <h2>Tournament Management</h2>
                    <div id="tournamentSelectContainer">
                        <select id="tournamentSelect">
                            <option value="">Select a tournament</option>
                        </select>
                    </div>
                    <div id="tournamentDetails"></div>
                    <button class="create-tournament-open-btn btn">Create Tournament</button>
                    <button class="edit-tournament-open-btn btn">Edit Tournament</button>
                    <button class="delete-tournament-btn btn">Delete Tournament</button>
                    <div id="createTournamentModal" class="modal">
                        <div class="modal-content">
                            ${dropdownUtils.createInput({ id: 'tournamentName', type: 'text', label: 'Tournament Name', placeholder: 'Enter tournament name' })}
                            ${dropdownUtils.createInput({ id: 'tournamentDate', type: 'date', label: 'Date' })}
                            ${dropdownUtils.createInput({ id: 'tournamentMaxTeams', type: 'number', label: 'Max Teams', placeholder: 'Enter max teams' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStacksPerTeam', type: 'number', label: 'Stacks per Team', placeholder: 'Enter stacks per team' })}
                            ${dropdownUtils.createInput({ id: 'tournamentLocation', type: 'text', label: 'Location', placeholder: 'Enter location' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStartTime', type: 'time', label: 'Start Time' })}
                            ${dropdownUtils.createInput({ id: 'tournamentType', type: 'text', label: 'Type', placeholder: 'Enter tournament type' })}
                            ${dropdownUtils.createInput({ id: 'tournamentMaxTables', type: 'number', label: 'Max Tables', placeholder: 'Enter max tables' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStackSize', type: 'number', label: 'Stack Size', placeholder: 'Enter stack size' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStatus', type: 'text', label: 'Status', placeholder: 'Enter status' })}
                            ${dropdownUtils.createInput({ id: 'tournamentOrganizer', type: 'text', label: 'Organizer', placeholder: 'Enter organizer' })}
                            ${dropdownUtils.createInput({ id: 'tournamentMaxSeatsPerTable', type: 'number', label: 'Max Seats per Table', placeholder: 'Enter max seats per table', defaultValue: 9 })}
                            ${dropdownUtils.createDropdown({ id: 'tournamentAllocationMode', label: 'Allocation Mode', options: ['Sequential', 'Random'], defaultValue: 'random' })}
                            <div class="modal-actions">
                                <button class="create-tournament-btn btn">Save</button>
                                <button class="cancel-btn btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                    <div id="editTournamentModal" class="modal">
                        <div class="modal-content">
                            ${dropdownUtils.createInput({ id: 'editTournamentName', type: 'text', label: 'Tournament Name', placeholder: 'Enter tournament name' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentDate', type: 'date', label: 'Date' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentMaxTeams', type: 'number', label: 'Max Teams', placeholder: 'Enter max teams' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStacksPerTeam', type: 'number', label: 'Stacks per Team', placeholder: 'Enter stacks per team' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentLocation', type: 'text', label: 'Location', placeholder: 'Enter location' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStartTime', type: 'time', label: 'Start Time' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentType', type: 'text', label: 'Type', placeholder: 'Enter tournament type' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentMaxTables', type: 'number', label: 'Max Tables', placeholder: 'Enter max tables' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStackSize', type: 'number', label: 'Stack Size', placeholder: 'Enter stack size' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStatus', type: 'text', label: 'Status', placeholder: 'Enter status' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentOrganizer', type: 'text', label: 'Organizer', placeholder: 'Enter organizer' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentMaxSeatsPerTable', type: 'number', label: 'Max Seats per Table', placeholder: 'Enter max seats per table', defaultValue: 9 })}
                            ${dropdownUtils.createDropdown({ id: 'editTournamentAllocationMode', label: 'Allocation Mode', options: ['Sequential', 'Random'], defaultValue: 'random' })}
                            <div class="modal-actions">
                                <button class="edit-tournament-btn btn">Save</button>
                                <button class="save-as-tournament-btn btn">Save As</button>
                                <button class="cancel-btn btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                    <button class="toggle-tournament-btn btn" data-section="checkInTeamsContainer">
                        Show Check-in Teams
                    </button>
                    <div id="checkInTeamsContainer" style="display: none;">
                        <h3>Check-in Teams</h3>
                        <ul id="checkInTeamsList"></ul>
                    </div>
                    <button class="toggle-tournament-btn btn" data-section="tableDistributionContainer">
                        Show Table Distribution
                    </button>
                    <div id="tableDistributionContainer" style="display: none;">
                        <h3>Table Distribution</h3>
                        <button class="generate-table-distribution-btn btn">Generate Table Distribution</button>
                        <button class="simulate-table-distribution-btn btn">Simulate Table Distribution</button>
                        <div id="simulateTableDistributionModal" class="modal">
                            <div class="modal-content">
                                ${dropdownUtils.createInput({ id: 'simulateNumTeams', type: 'number', label: 'Number of Teams', placeholder: 'Enter number of teams' })}
                                ${dropdownUtils.createInput({ id: 'simulateMaxTables', type: 'number', label: 'Max Tables', placeholder: 'Enter max tables' })}
                                ${dropdownUtils.createInput({ id: 'simulateStacksPerTeam', type: 'number', label: 'Stacks per Team', placeholder: 'Enter stacks per team' })}
                                ${dropdownUtils.createInput({ id: 'simulateMaxSeatsPerTable', type: 'number', label: 'Max Seats per Table', placeholder: 'Enter max seats per table', defaultValue: 9 })}
                                ${dropdownUtils.createDropdown({ id: 'simulateAllocationMode', label: 'Allocation Mode', options: ['Sequential', 'Random'], defaultValue: 'random' })}
                                <div class="modal-actions">
                                    <button class="simulate-table-distribution-btn btn">Simulate</button>
                                    <button class="cancel-btn btn">Cancel</button>
                                </div>
                            </div>
                        </div>
                        <div id="tableDistributionList"></div>
                    </div>
                </div>
            `;
            console.log('TournamentCheckIn content rendered in tournamentManagementContainer:', tournamentManagementContainer.innerHTML);
        }
    }
}

export default TournamentCheckIn;