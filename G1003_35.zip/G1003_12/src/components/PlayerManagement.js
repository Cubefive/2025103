 import dropdownUtils from '../utils/dropdownUtils.js';
import PlayerList from './PlayerList.js';
import PlayerCreation from './PlayerCreation.js';
import PlayerEdit from './PlayerEdit.js';

class PlayerManagement {
    constructor({ rootElement, storage }) {
        console.log('Constructing PlayerManagement with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.playerList = null;
        this.playerCreation = null;
        this.playerEdit = null;
        this.init();
    }

    init() {
        console.log('Initializing PlayerManagement');
        this.render();
        this.refreshTeamSelect();
    }

    refreshTeamSelect() {
        console.log('Refreshing team select dropdowns');
        const teamSelect = document.getElementById('teamSelect');
        const editTeamSelect = document.getElementById('editTeamSelect');
        if (this.storage && this.storage.getTeams) {
            const teams = this.storage.getTeams();
            console.log('Teams for dropdown:', teams);
            if (teamSelect) {
                uiUtils.renderTeamDropdown(teams, '', 'teamSelect');
                console.log('teamSelect populated:', teamSelect.innerHTML);
            } else {
                console.log('teamSelect not found in DOM');
            }
            if (editTeamSelect) {
                uiUtils.renderTeamDropdown(teams, '', 'editTeamSelect');
                console.log('editTeamSelect populated:', editTeamSelect.innerHTML);
            } else {
                console.log('editTeamSelect not found in DOM');
            }
        }
    }

    setupEventListeners() {
        console.log('Setting up event listeners for PlayerManagement');
        const createPlayerBtn = document.querySelector('.create-player-btn');
        if (createPlayerBtn) {
            createPlayerBtn.addEventListener('click', () => {
                console.log('Create Player button clicked');
                this.playerCreation.openCreatePlayerModal();
            });
        } else {
            console.log('create-player-btn not found in DOM');
        }
    }

    render() {
        console.log('PlayerManagement rendering');
        const playerManagementContainer = document.getElementById('playerManagementContainer');
        if (playerManagementContainer) {
            playerManagementContainer.innerHTML = `
                <h2>Player Management</h2>
                <button class="create-player-btn btn">Create Player</button>
                <div id="createPlayerModal" class="modal">
                    <div class="modal-content">
                        ${dropdownUtils.createInput({ id: 'firstName', type: 'text', label: 'First Name', placeholder: 'Enter first name' })}
                        ${dropdownUtils.createInput({ id: 'lastName', type: 'text', label: 'Last Name', placeholder: 'Enter last name' })}
                        ${dropdownUtils.createInput({ id: 'nickname', type: 'text', label: 'Nickname', placeholder: 'Enter nickname' })}
                        ${dropdownUtils.createInput({ id: 'email', type: 'email', label: 'Email', placeholder: 'Enter email' })}
                        ${dropdownUtils.createInput({ id: 'phoneNumber', type: 'text', label: 'Phone Number', placeholder: 'Enter phone number' })}
                        ${dropdownUtils.createDropdown({ id: 'teamSelect', label: 'Team' })}
                        ${dropdownUtils.createInput({ id: 'isCaptain', type: 'checkbox', label: 'Is Captain' })}
                        <div class="modal-actions">
                            <button class="save-player-btn btn">Save</button>
                            <button class="cancel-btn btn">Cancel</button>
                        </div>
                    </div>
                </div>
                <div id="editPlayerModal" class="modal">
                    <div class="modal-content">
                        ${dropdownUtils.createInput({ id: 'editFirstName', type: 'text', label: 'First Name', placeholder: 'Enter first name' })}
                        ${dropdownUtils.createInput({ id: 'editLastName', type: 'text', label: 'Last Name', placeholder: 'Enter last name' })}
                        ${dropdownUtils.createInput({ id: 'editNickname', type: 'text', label: 'Nickname', placeholder: 'Enter nickname' })}
                        ${dropdownUtils.createInput({ id: 'editEmail', type: 'email', label: 'Email', placeholder: 'Enter email' })}
                        ${dropdownUtils.createInput({ id: 'editPhoneNumber', type: 'text', label: 'Phone Number', placeholder: 'Enter phone number' })}
                        ${dropdownUtils.createDropdown({ id: 'editTeamSelect', label: 'Team' })}
                        ${dropdownUtils.createInput({ id: 'editIsCaptain', type: 'checkbox', label: 'Is Captain' })}
                        <div class="modal-actions">
                            <button class="save-edit-player-btn btn">Save</button>
                            <button class="cancel-btn btn">Cancel</button>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label for="playerSearchInput">Search Players:</label>
                    <div class="search-container">
                        <span class="search-icon">🔍</span>
                        <input type="text" id="playerSearchInput" placeholder="Search players...">
                        <span class="clear-icon player-clear-icon" style="display: none;">X</span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="teamFilterInput">Filter by Team:</label>
                    <div class="search-container">
                        <span class="search-icon">🔍</span>
                        <input type="text" id="teamFilterInput" placeholder="To be added" disabled>
                    </div>
                    <select id="teamFilterSelect" class="team-select">
                        <option value="">All Teams</option>
                    </select>
                </div>
                <table id="playerDatabaseTable" border="1" style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Nickname</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Team</th>
                            <th>Captain</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            `;
            console.log('PlayerManagement content rendered in playerManagementContainer:', playerManagementContainer.innerHTML);

            try {
                this.playerList = new PlayerList({ container: playerManagementContainer, storage: this.storage });
            } catch (error) {
                console.error('Error initializing PlayerList:', error);
            }
            try {
                this.playerCreation = new PlayerCreation({ playerContainer: playerManagementContainer, storage: this.storage });
            } catch (error) {
                console.error('Error initializing PlayerCreation:', error);
            }
            try {
                this.playerEdit = new PlayerEdit({ playerContainer: playerManagementContainer, storage: this.storage });
            } catch (error) {
                console.error('Error initializing PlayerEdit:', error);
            }

            this.setupEventListeners();
        }
    }
}

export default PlayerManagement;