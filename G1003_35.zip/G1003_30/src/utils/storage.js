 import TeamStorage from './TeamStorage.js';
import TournamentStorage from './TournamentStorage.js';
import TableDistribution from './TableDistribution.js';

class Storage {
    constructor() {
        console.log('Constructing Storage with storages:', {
            TeamStorage,
            TournamentStorage,
            TableDistribution
        });
        this.playerDatabase = [];
        this.teamStorage = new TeamStorage(this);
        this.tournamentStorage = new TournamentStorage();
        this.tableDistribution = new TableDistribution();
        this.loadPlayerDatabase();
    }

    loadPlayerDatabase() {
        console.log('Loading playerDatabase');
        const rawPlayerDatabase = localStorage.getItem('playerDatabase');
        console.log('Raw playerDatabase from localStorage:', rawPlayerDatabase);
        this.playerDatabase = rawPlayerDatabase ? JSON.parse(rawPlayerDatabase) : [
            { id: '1', firstName: 'Alice', lastName: 'Adams', nickname: 'Ace', email: 'alice@example.com', phoneNumber: '123-456-7890', teamId: null, isCaptain: false },
            { id: '2', firstName: 'Adam', lastName: 'Allen', nickname: 'AceKicker', email: 'adam@example.com', phoneNumber: '123-456-7891', teamId: null, isCaptain: false },
            { id: '3', firstName: 'Amelia', lastName: 'Anderson', nickname: 'Amy', email: 'amelia@example.com', phoneNumber: '123-456-7892', teamId: null, isCaptain: false },
            { id: '4', firstName: 'Arthur', lastName: 'Andrews', nickname: 'Art', email: 'arthur@example.com', phoneNumber: '123-456-7893', teamId: null, isCaptain: false },
            { id: '5', firstName: 'Bob', lastName: 'Baker', nickname: 'Buster', email: 'bob@example.com', phoneNumber: '123-456-7894', teamId: null, isCaptain: false },
            { id: '6', firstName: 'Beth', lastName: 'Barnes', nickname: 'Betty', email: 'beth@example.com', phoneNumber: '123-456-7895', teamId: null, isCaptain: false },
            { id: '7', firstName: 'Bella', lastName: 'Bennett', nickname: 'Bell', email: 'bella@example.com', phoneNumber: '123-456-7896', teamId: null, isCaptain: false },
            { id: '8', firstName: 'Ben', lastName: 'Brooks', nickname: 'Benny', email: 'ben@example.com', phoneNumber: '123-456-7897', teamId: null, isCaptain: false },
            { id: '9', firstName: 'Charlie', lastName: 'Carter', nickname: 'Chuck', email: 'charlie@example.com', phoneNumber: '123-456-7898', teamId: null, isCaptain: false },
            { id: '10', firstName: 'Chloe', lastName: 'Clark', nickname: 'Clo', email: 'chloe@example.com', phoneNumber: '123-456-7899', teamId: null, isCaptain: false },
            { id: '11', firstName: 'Caleb', lastName: 'Collins', nickname: 'Cal', email: 'caleb@example.com', phoneNumber: '123-456-7900', teamId: null, isCaptain: false },
            { id: '12', firstName: 'Clara', lastName: 'Cooper', nickname: 'Clare', email: 'clara@example.com', phoneNumber: '123-456-7901', teamId: null, isCaptain: false },
            { id: '13', firstName: 'David', lastName: 'Davis', nickname: 'Dave', email: 'david@example.com', phoneNumber: '123-456-7902', teamId: null, isCaptain: false },
            { id: '14', firstName: 'Daisy', lastName: 'Dean', nickname: 'Daze', email: 'daisy@example.com', phoneNumber: '123-456-7903', teamId: null, isCaptain: false },
            { id: '15', firstName: 'Daniel', lastName: 'Dixon', nickname: 'Dan', email: 'daniel@example.com', phoneNumber: '123-456-7904', teamId: null, isCaptain: false },
            { id: '16', firstName: 'Diana', lastName: 'Dunn', nickname: 'Di', email: 'diana@example.com', phoneNumber: '123-456-7905', teamId: null, isCaptain: false },
            { id: '17', firstName: 'Emma', lastName: 'Edwards', nickname: 'Em', email: 'emma@example.com', phoneNumber: '123-456-7906', teamId: null, isCaptain: false },
            { id: '18', firstName: 'Ethan', lastName: 'Ellis', nickname: 'Eth', email: 'ethan@example.com', phoneNumber: '123-456-7907', teamId: null, isCaptain: false },
            { id: '19', firstName: 'Ella', lastName: 'Evans', nickname: 'Ellie', email: 'ella@example.com', phoneNumber: '123-456-7908', teamId: null, isCaptain: false },
            { id: '20', firstName: 'Evan', lastName: 'Emerson', nickname: 'Ev', email: 'evan@example.com', phoneNumber: '123-456-7909', teamId: null, isCaptain: false },
            { id: '21', firstName: 'Fiona', lastName: 'Fisher', nickname: 'Fi', email: 'fiona@example.com', phoneNumber: '123-456-7910', teamId: null, isCaptain: false },
            { id: '22', firstName: 'Finn', lastName: 'Ford', nickname: 'Finny', email: 'finn@example.com', phoneNumber: '123-456-7911', teamId: null, isCaptain: false },
            { id: '23', firstName: 'Faith', lastName: 'Foster', nickname: 'Fay', email: 'faith@example.com', phoneNumber: '123-456-7912', teamId: null, isCaptain: false },
            { id: '24', firstName: 'Felix', lastName: 'Fox', nickname: 'Fel', email: 'felix@example.com', phoneNumber: '123-456-7913', teamId: null, isCaptain: false },
            { id: '25', firstName: 'Grace', lastName: 'Gibson', nickname: 'Gracie', email: 'grace@example.com', phoneNumber: '123-456-7914', teamId: null, isCaptain: false },
            { id: '26', firstName: 'Gavin', lastName: 'Gordon', nickname: 'Gav', email: 'gavin@example.com', phoneNumber: '123-456-7915', teamId: null, isCaptain: false },
            { id: '27', firstName: 'Gemma', lastName: 'Grant', nickname: 'Gem', email: 'gemma@example.com', phoneNumber: '123-456-7916', teamId: null, isCaptain: false },
            { id: '28', firstName: 'George', lastName: 'Gray', nickname: 'Geo', email: 'george@example.com', phoneNumber: '123-456-7917', teamId: null, isCaptain: false },
            { id: '29', firstName: 'Hannah', lastName: 'Harris', nickname: 'Han', email: 'hannah@example.com', phoneNumber: '123-456-7918', teamId: null, isCaptain: false },
            { id: '30', firstName: 'Henry', lastName: 'Hayes', nickname: 'Hank', email: 'henry@example.com', phoneNumber: '123-456-7919', teamId: null, isCaptain: false },
            { id: '31', firstName: 'Hazel', lastName: 'Hill', nickname: 'Haze', email: 'hazel@example.com', phoneNumber: '123-456-7920', teamId: null, isCaptain: false },
            { id: '32', firstName: 'Hugo', lastName: 'Howard', nickname: 'Hugh', email: 'hugo@example.com', phoneNumber: '123-456-7921', teamId: null, isCaptain: false },
            { id: '33', firstName: 'Isabella', lastName: 'Ingram', nickname: 'Bella', email: 'isabella@example.com', phoneNumber: '123-456-7922', teamId: null, isCaptain: false },
            { id: '34', firstName: 'Isaac', lastName: 'Irwin', nickname: 'Ike', email: 'isaac@example.com', phoneNumber: '123-456-7923', teamId: null, isCaptain: false },
            { id: '35', firstName: 'Isla', lastName: 'Irving', nickname: 'Isle', email: 'isla@example.com', phoneNumber: '123-456-7924', teamId: null, isCaptain: false },
            { id: '36', firstName: 'Ian', lastName: 'Innes', nickname: 'I', email: 'ian@example.com', phoneNumber: '123-456-7925', teamId: null, isCaptain: false },
            { id: '37', firstName: 'Jack', lastName: 'Jackson', nickname: 'Jay', email: 'jack@example.com', phoneNumber: '123-456-7926', teamId: null, isCaptain: false },
            { id: '38', firstName: 'Jade', lastName: 'James', nickname: 'Jay', email: 'jade@example.com', phoneNumber: '123-456-7927', teamId: null, isCaptain: false },
            { id: '39', firstName: 'Jake', lastName: 'Jenkins', nickname: 'J', email: 'jake@example.com', phoneNumber: '123-456-7928', teamId: null, isCaptain: false },
            { id: '40', firstName: 'Jasmine', lastName: 'Jones', nickname: 'Jazz', email: 'jasmine@example.com', phoneNumber: '123-456-7929', teamId: null, isCaptain: false },
            { id: '41', firstName: 'Kate', lastName: 'Kelly', nickname: 'Katie', email: 'kate@example.com', phoneNumber: '123-456-7930', teamId: null, isCaptain: false },
            { id: '42', firstName: 'Kevin', lastName: 'King', nickname: 'Kev', email: 'kevin@example.com', phoneNumber: '123-456-7931', teamId: null, isCaptain: false },
            { id: '43', firstName: 'Kylie', lastName: 'Knight', nickname: 'Ky', email: 'kylie@example.com', phoneNumber: '123-456-7932', teamId: null, isCaptain: false },
            { id: '44', firstName: 'Kyle', lastName: 'Kerr', nickname: 'K', email: 'kyle@example.com', phoneNumber: '123-456-7933', teamId: null, isCaptain: false },
            { id: '45', firstName: 'Lily', lastName: 'Lewis', nickname: 'Lil', email: 'lily@example.com', phoneNumber: '123-456-7934', teamId: null, isCaptain: false },
            { id: '46', firstName: 'Liam', lastName: 'Lloyd', nickname: 'Lee', email: 'liam@example.com', phoneNumber: '123-456-7935', teamId: null, isCaptain: false },
            { id: '47', firstName: 'Lucas', lastName: 'Lane', nickname: 'Luke', email: 'lucas@example.com', phoneNumber: '123-456-7936', teamId: null, isCaptain: false },
            { id: '48', firstName: 'Luna', lastName: 'Lawrence', nickname: 'Lu', email: 'luna@example.com', phoneNumber: '123-456-7937', teamId: null, isCaptain: false },
            { id: '49', firstName: 'Mason', lastName: 'Mason', nickname: 'Mase', email: 'mason@example.com', phoneNumber: '123-456-7938', teamId: null, isCaptain: false },
            { id: '50', firstName: 'Mia', lastName: 'Matthews', nickname: 'Mimi', email: 'mia@example.com', phoneNumber: '123-456-7939', teamId: null, isCaptain: false },
            { id: '51', firstName: 'Max', lastName: 'Mills', nickname: 'Maxi', email: 'max@example.com', phoneNumber: '123-456-7940', teamId: null, isCaptain: false },
            { id: '52', firstName: 'Molly', lastName: 'Mitchell', nickname: 'Mol', email: 'molly@example.com', phoneNumber: '123-456-7941', teamId: null, isCaptain: false },
            { id: '53', firstName: 'Noah', lastName: 'Nelson', nickname: 'Noe', email: 'noah@example.com', phoneNumber: '123-456-7942', teamId: null, isCaptain: false },
            { id: '54', firstName: 'Nora', lastName: 'Nichols', nickname: 'Nor', email: 'nora@example.com', phoneNumber: '123-456-7943', teamId: null, isCaptain: false },
            { id: '55', firstName: 'Nathan', lastName: 'Norris', nickname: 'Nate', email: 'nathan@example.com', phoneNumber: '123-456-7944', teamId: null, isCaptain: false },
            { id: '56', firstName: 'Naomi', lastName: 'Newman', nickname: 'Nao', email: 'naomi@example.com', phoneNumber: '123-456-7945', teamId: null, isCaptain: false },
            { id: '57', firstName: 'Olivia', lastName: 'Owens', nickname: 'Liv', email: 'olivia@example.com', phoneNumber: '123-456-7946', teamId: null, isCaptain: false },
            { id: '58', firstName: 'Oscar', lastName: 'Oliver', nickname: 'Oz', email: 'oscar@example.com', phoneNumber: '123-456-7947', teamId: null, isCaptain: false },
            { id: '59', firstName: 'Owen', lastName: 'Ortega', nickname: 'O', email: 'owen@example.com', phoneNumber: '123-456-7948', teamId: null, isCaptain: false },
            { id: '60', firstName: 'Olive', lastName: 'Osborne', nickname: 'Ollie', email: 'olive@example.com', phoneNumber: '123-456-7949', teamId: null, isCaptain: false }
        ];
        console.log('Loaded playerDatabase:', this.playerDatabase);
    }

    savePlayerDatabase(playerDatabase) {
        console.log('Saving playerDatabase:', playerDatabase);
        this.playerDatabase = playerDatabase;
        localStorage.setItem('playerDatabase', JSON.stringify(this.playerDatabase));
        console.log('playerDatabase saved to localStorage');
        window.dispatchEvent(new Event('playerDatabaseUpdated'));
    }

    getPlayerDatabase() {
        console.log('Getting player database');
        return this.playerDatabase;
    }

    addPlayer(player) {
        console.log('Adding player:', player);
        this.playerDatabase.push(player);
        this.savePlayerDatabase(this.playerDatabase);
    }

    updatePlayer(playerId, updatedPlayer) {
        console.log('Updating player:', playerId, updatedPlayer);
        const index = this.playerDatabase.findIndex(p => p.id === playerId);
        if (index !== -1) {
            this.playerDatabase[index] = { ...this.playerDatabase[index], ...updatedPlayer };
            this.savePlayerDatabase(this.playerDatabase);
        }
    }

    deletePlayer(playerId) {
        console.log('Deleting player:', playerId);
        this.playerDatabase = this.playerDatabase.filter(p => p.id !== playerId);
        this.savePlayerDatabase(this.playerDatabase);
    }

    getTeams() {
        console.log('Getting teams');
        return this.teamStorage.getTeams();
    }

    addTeam(team) {
        console.log('Adding team:', team);
        this.teamStorage.addTeam(team);
    }

    updateTeam(teamId, team) {
        console.log('Updating team:', teamId, team);
        this.teamStorage.updateTeam(teamId, team);
    }

    deleteTeam(teamId) {
        console.log('Deleting team:', teamId);
        this.teamStorage.deleteTeam(teamId);
    }

    getTeam(teamId) {
        console.log('Getting team:', teamId);
        return this.teamStorage.getTeam(teamId);
    }

    getTournaments() {
        console.log('Getting tournament database');
        return this.tournamentStorage.getTournaments();
    }

    addTournament(tournament) {
        console.log('Adding tournament:', tournament);
        this.tournamentStorage.addTournament(tournament);
    }

    updateTournament(tournamentId, tournament) {
        console.log('Updating tournament:', tournamentId, tournament);
        this.tournamentStorage.updateTournament(tournamentId, tournament);
    }

    deleteTournament(tournamentId) {
        console.log('Deleting tournament:', tournamentId);
        this.tournamentStorage.deleteTournament(tournamentId);
    }

    getTables() {
        console.log('Getting table database');
        return this.tableDistribution.getTables();
    }

    addTable(table) {
        console.log('Adding table:', table);
        this.tableDistribution.addTable(table);
    }

    updateTable(tableId, table) {
        console.log('Updating table:', tableId, table);
        this.tableDistribution.updateTable(tableId, table);
    }

    deleteTable(tableId) {
        console.log('Deleting table:', tableId);
        this.tableDistribution.deleteTable(tableId);
    }
}

export default Storage;