 const uiUtils = {
    renderTable(tableId, data, fields, type) {
        console.log(`Rendering table for type: ${type}, with data:`, data);
        console.log('Fields for rendering:', fields);
        const table = document.getElementById(tableId);
        if (!table) {
            console.log(`Table with ID ${tableId} not found`);
            return;
        }
        const tbody = table.querySelector('tbody');
        if (!tbody) {
            console.log(`No tbody found in table ${tableId}`);
            return;
        }
        tbody.innerHTML = '';
        data.forEach(item => {
            const row = document.createElement('tr');
            fields.forEach(field => {
                const cell = document.createElement('td');
                if (field.render) {
                    cell.innerHTML = field.render(item[field.key], item);
                } else {
                    cell.textContent = item[field.key] || '';
                }
                row.appendChild(cell);
            });
            tbody.appendChild(row);
        });
        console.log(`Table ${tableId} rendered successfully`);
        console.log(`Table ${tableId} tbody content:`, tbody.innerHTML);
    },

    renderTeamDropdown(items, defaultValue, elementId, multiple = false) {
        console.log(`Rendering team dropdown with items:`, items);
        const select = document.getElementById(elementId);
        if (!select) {
            console.log(`Dropdown with ID ${elementId} not found`);
            return;
        }
        select.innerHTML = multiple
            ? '<option value="">Select multiple</option>'
            : '<option value="">Select one</option>';
        items.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = `${item.firstName} ${item.lastName}`;
            select.appendChild(option);
        });
        if (defaultValue) {
            select.value = defaultValue;
        }
        console.log(`Dropdown ${elementId} rendered successfully`);
        console.log(`Dropdown ${elementId} content:`, select.innerHTML);
    },

    renderTournamentDropdown(tournaments, defaultValue, elementId) {
        console.log(`Rendering tournament dropdown with tournaments:`, tournaments);
        const select = document.getElementById(elementId);
        if (!select) {
            console.log(`Dropdown with ID ${elementId} not found`);
            return;
        }
        select.innerHTML = '<option value="">Select a tournament</option>';
        tournaments.forEach(tournament => {
            const option = document.createElement('option');
            option.value = tournament.id;
            option.textContent = `${tournament.name} (${tournament.date})`;
            select.appendChild(option);
        });
        if (defaultValue) {
            select.value = defaultValue;
        }
        console.log(`Tournament dropdown ${elementId} rendered successfully`);
        console.log(`Tournament dropdown ${elementId} content:`, select.innerHTML);
    }
};

export { uiUtils };