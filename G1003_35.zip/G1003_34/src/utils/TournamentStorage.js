 class TournamentStorage {
    constructor() {
        console.log('Constructing TournamentStorage');
        this.tournamentDatabase = [];
        this.loadTournamentDatabase();
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TournamentStorage');
        window.addEventListener('teamDatabaseUpdated', () => {
            console.log('teamDatabaseUpdated event received in TournamentStorage');
            this.syncTournamentsWithTeams();
        });
    }

    loadTournamentDatabase() {
        console.log('Loading tournament database from localStorage');
        const rawTournamentDatabase = localStorage.getItem('tournamentDatabase');
        console.log('Raw tournamentDatabase from localStorage:', rawTournamentDatabase);
        if (rawTournamentDatabase) {
            this.tournamentDatabase = JSON.parse(rawTournamentDatabase);
        } else {
            this.tournamentDatabase = [
                {
                    id: 't1',
                    name: 'Test Tournament 2025',
                    date: '2025-06-15',
                    maxTeams: 16,
                    stacksPerTeam: 4,
                    location: 'Casino',
                    startTime: '10:00',
                    type: 'No Limit Hold\'em',
                    maxTables: 4,
                    stackSize: 10000,
                    status: 'Upcoming',
                    organizer: 'Poker Club',
                    maxSeatsPerTable: 9,
                    allocationMode: 'random',
                    checkedInTeams: ['1', '2', '3', '4', '5'],
                    startTimestamp: null
                },
                {
                    id: 't2',
                    name: 'October Classic',
                    date: '2025-10-18',
                    maxTeams: 10,
                    stacksPerTeam: 3,
                    location: 'Krukan',
                    startTime: '12:00',
                    type: 'Pot Limit Omaha',
                    maxTables: 3,
                    stackSize: 15000,
                    status: 'Upcoming',
                    organizer: 'Krukan Poker Society',
                    maxSeatsPerTable: 9,
                    allocationMode: 'random',
                    checkedInTeams: [],
                    startTimestamp: null
                }
            ];
            this.saveTournamentDatabase();
            console.log('No tournamentDatabase found in localStorage, initialized with default data:', this.tournamentDatabase.length, 'tournaments');
        }
        console.log('Loaded tournamentDatabase:', this.tournamentDatabase);
    }

    syncTournamentsWithTeams() {
        console.log('Syncing tournaments with teams');
        // Placeholder for team synchronization logic
        this.saveTournamentDatabase();
    }

    saveTournamentDatabase() {
        console.log('Saving tournament database to localStorage:', this.tournamentDatabase);
        localStorage.setItem('tournamentDatabase', JSON.stringify(this.tournamentDatabase));
        console.log('Tournament database saved successfully:', this.tournamentDatabase.length, 'tournaments');
        window.dispatchEvent(new Event('tournamentDatabaseUpdated'));
    }

    getTournaments() {
        console.log('Getting tournament database');
        return this.tournamentDatabase;
    }

    getTournament(tournamentId) {
        console.log('Getting tournament:', tournamentId);
        return this.tournamentDatabase.find(tournament => tournament.id === tournamentId);
    }

    addTournament(tournament) {
        console.log('Adding tournament:', tournament);
        this.tournamentDatabase.push(tournament);
        this.saveTournamentDatabase();
    }

    updateTournament(tournamentId, tournament) {
        console.log('Updating tournament:', tournamentId, tournament);
        const index = this.tournamentDatabase.findIndex(t => t.id === tournamentId);
        if (index !== -1) {
            this.tournamentDatabase[index] = { ...this.tournamentDatabase[index], ...tournament };
            this.saveTournamentDatabase();
        }
    }

    deleteTournament(tournamentId) {
        console.log('Deleting tournament:', tournamentId);
        this.tournamentDatabase = this.tournamentDatabase.filter(tournament => tournament.id !== tournamentId);
        this.saveTournamentDatabase();
    }
}

export default TournamentStorage;