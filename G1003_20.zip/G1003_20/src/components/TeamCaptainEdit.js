 import { modalUtils } from '../utils/modalUtils.js';
import dropdownUtils from '../utils/dropdownUtils.js';
import { renderTeamDropdown } from '../utils/uiUtils.js';

class TeamCaptainEdit {
    constructor({ rootElement, storage }) {
        console.log('Constructing TeamCaptainEdit with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.init();
    }

    init() {
        console.log('Initializing TeamCaptainEdit');
        this.setupEventListeners();
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TeamCaptainEdit');
        const editCaptainButtons = document.querySelectorAll('.edit-captain-btn');
        editCaptainButtons.forEach(button => {
            button.addEventListener('click', () => {
                console.log('Edit Captain button clicked:', button.dataset.teamId);
                this.openEditCaptainModal(button.dataset.teamId);
            });
        });

        const saveCaptainBtn = document.querySelector('.save-captain-btn');
        if (saveCaptainBtn) {
            saveCaptainBtn.addEventListener('click', (e) => {
                console.log('Save Captain button clicked');
                this.handleEditCaptain(e);
            });
        } else {
            console.log('save-captain-btn not found in DOM');
        }

        const cancelBtn = document.querySelector('#editCaptainModal .cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                console.log('Cancel button clicked');
                this.closeEditCaptainModal();
            });
        } else {
            console.log('cancel-btn not found in DOM');
        }
    }

    openEditCaptainModal(teamId) {
        console.log('Opening edit captain modal for teamId:', teamId);
        const modal = document.getElementById('editCaptainModal');
        if (modal && this.storage && this.storage.getTeam && this.storage.getPlayerDatabase) {
            const team = this.storage.getTeam(teamId);
            if (team) {
                const editCaptainSelect = document.getElementById('editCaptainSelect');
                if (editCaptainSelect) {
                    const players = this.storage.getPlayerDatabase().filter(player => team.playerIds.includes(player.id));
                    console.log('Players for editCaptainSelect:', players);
                    renderTeamDropdown(players, team.captainId, 'editCaptainSelect', false);
                    console.log('editCaptainSelect populated:', editCaptainSelect.innerHTML);
                }
                modalUtils.showModal('editCaptainModal', teamId);
            }
        }
    }

    handleEditCaptain(e) {
        e.preventDefault();
        const modal = document.getElementById('editCaptainModal');
        const teamId = modal.dataset.modalData;
        const editCaptainSelect = document.getElementById('editCaptainSelect');
        const captainId = editCaptainSelect.value;

        if (captainId) {
            console.log('Updating captain for team:', teamId, 'to captainId:', captainId);
            this.storage.updateTeam(teamId, { captainId });
            this.closeEditCaptainModal();
            console.log('Captain updated successfully');
        }
    }

    closeEditCaptainModal() {
        console.log('Closing edit captain modal');
        modalUtils.hideModal('editCaptainModal');
        const editCaptainSelect = document.getElementById('editCaptainSelect');
        if (editCaptainSelect) {
            editCaptainSelect.selectedIndex = -1;
        }
    }
}

export default TeamCaptainEdit;