 class TournamentCheckIn {
    constructor({ rootElement, storage }) {
        console.log('Constructing TournamentCheckIn with rootElement:', rootElement);
        this.rootElement = rootElement;
        this.storage = storage;
        this.init();
    }

    init() {
        console.log('Initializing TournamentCheckIn');
        this.render();
        this.loadTournamentSectionVisibility();
    }

    loadTournamentSectionVisibility() {
        console.log('Loading tournament section visibility from localStorage');
        const visibility = JSON.parse(localStorage.getItem('tournamentSectionVisibility')) || {
            checkInTeamsContainer: false,
            tableDistributionContainer: false
        };
        console.log('Tournament section visibility:', visibility);
        if (visibility.checkInTeamsContainer) {
            const checkInTeamsContainer = document.getElementById('checkInTeamsContainer');
            if (checkInTeamsContainer) {
                checkInTeamsContainer.style.display = 'block';
            }
        }
        if (visibility.tableDistributionContainer) {
            const tableDistributionContainer = document.getElementById('tableDistributionContainer');
            if (tableDistributionContainer) {
                tableDistributionContainer.style.display = 'block';
            }
        }
    }

    setupEventListeners() {
        console.log('Setting up event listeners for TournamentCheckIn');
        const tournamentSelect = document.getElementById('tournamentSelect');
        if (tournamentSelect) {
            tournamentSelect.addEventListener('change', () => {
                console.log('Tournament select changed:', tournamentSelect.value);
                this.refreshTournamentDetails(tournamentSelect.value);
                this.refreshCheckInTeams(tournamentSelect.value);
            });
        } else {
            console.log('tournamentSelect not found in DOM');
        }

        const createTournamentBtn = document.querySelector('.create-tournament-open-btn');
        if (createTournamentBtn) {
            createTournamentBtn.addEventListener('click', () => {
                console.log('Create Tournament button clicked');
                modalUtils.showModal('createTournamentModal');
            });
        } else {
            console.log('create-tournament-open-btn not found in DOM');
        }

        const editTournamentBtn = document.querySelector('.edit-tournament-open-btn');
        if (editTournamentBtn) {
            editTournamentBtn.addEventListener('click', () => {
                console.log('Edit Tournament button clicked');
                this.openEditTournamentModal();
            });
        } else {
            console.log('edit-tournament-open-btn not found in DOM');
        }

        const deleteTournamentBtn = document.querySelector('.delete-tournament-btn');
        if (deleteTournamentBtn) {
            deleteTournamentBtn.addEventListener('click', () => {
                console.log('Delete Tournament button clicked');
                this.deleteTournament();
            });
        } else {
            console.log('delete-tournament-btn not found in DOM');
        }

        const saveTournamentBtn = document.querySelector('.create-tournament-btn');
        if (saveTournamentBtn) {
            saveTournamentBtn.addEventListener('click', () => {
                console.log('Save Tournament button clicked');
                this.handleCreateTournament();
            });
        } else {
            console.log('create-tournament-btn not found in DOM');
        }

        const cancelCreateTournamentBtn = document.querySelector('#createTournamentModal .cancel-btn');
        if (cancelCreateTournamentBtn) {
            cancelCreateTournamentBtn.addEventListener('click', () => {
                console.log('Cancel create tournament button clicked');
                modalUtils.hideModal('createTournamentModal');
            });
        } else {
            console.log('createTournamentModal cancel-btn not found in DOM');
        }

        const saveEditTournamentBtn = document.querySelector('.edit-tournament-btn');
        if (saveEditTournamentBtn) {
            saveEditTournamentBtn.addEventListener('click', () => {
                console.log('Save Edit Tournament button clicked');
                this.handleEditTournament();
            });
        } else {
            console.log('edit-tournament-btn not found in DOM');
        }

        const saveAsTournamentBtn = document.querySelector('.save-as-tournament-btn');
        if (saveAsTournamentBtn) {
            saveAsTournamentBtn.addEventListener('click', () => {
                console.log('Save As Tournament button clicked');
                this.handleSaveAsTournament();
            });
        } else {
            console.log('save-as-tournament-btn not found in DOM');
        }

        const cancelEditTournamentBtn = document.querySelector('#editTournamentModal .cancel-btn');
        if (cancelEditTournamentBtn) {
            cancelEditTournamentBtn.addEventListener('click', () => {
                console.log('Cancel edit tournament button clicked');
                modalUtils.hideModal('editTournamentModal');
            });
        } else {
            console.log('editTournamentModal cancel-btn not found in DOM');
        }

        const toggleCheckInTeamsBtn = document.querySelector('.toggle-tournament-btn[data-section="checkInTeamsContainer"]');
        if (toggleCheckInTeamsBtn) {
            toggleCheckInTeamsBtn.addEventListener('click', () => {
                console.log('Toggle Check-in Teams button clicked');
                this.toggleTournamentSection('checkInTeamsContainer');
            });
        } else {
            console.log('toggle-tournament-btn for checkInTeamsContainer not found in DOM');
        }

        const toggleTableDistributionBtn = document.querySelector('.toggle-tournament-btn[data-section="tableDistributionContainer"]');
        if (toggleTableDistributionBtn) {
            toggleTableDistributionBtn.addEventListener('click', () => {
                console.log('Toggle Table Distribution button clicked');
                this.toggleTournamentSection('tableDistributionContainer');
            });
        } else {
            console.log('toggle-tournament-btn for tableDistributionContainer not found in DOM');
        }

        const generateTableDistributionBtn = document.querySelector('.generate-table-distribution-btn');
        if (generateTableDistributionBtn) {
            generateTableDistributionBtn.addEventListener('click', () => {
                console.log('Generate Table Distribution button clicked');
                this.generateTableDistribution();
            });
        } else {
            console.log('generate-table-distribution-btn not found in DOM');
        }

        const simulateTableDistributionBtn = document.querySelector('.simulate-table-distribution-btn');
        if (simulateTableDistributionBtn) {
            simulateTableDistributionBtn.addEventListener('click', () => {
                console.log('Simulate Table Distribution button clicked');
                modalUtils.showModal('simulateTableDistributionModal');
            });
        } else {
            console.log('simulate-table-distribution-btn not found in DOM');
        }

        const simulateBtn = document.querySelector('#simulateTableDistributionModal .simulate-table-distribution-btn');
        if (simulateBtn) {
            simulateBtn.addEventListener('click', () => {
                console.log('Simulate button clicked');
                this.simulateTableDistribution();
            });
        } else {
            console.log('simulate-table-distribution-btn not found in DOM');
        }

        const cancelSimulateBtn = document.querySelector('#simulateTableDistributionModal .cancel-btn');
        if (cancelSimulateBtn) {
            cancelSimulateBtn.addEventListener('click', () => {
                console.log('Cancel simulate button clicked');
                modalUtils.hideModal('simulateTableDistributionModal');
            });
        } else {
            console.log('simulateTableDistributionModal cancel-btn not found in DOM');
        }
    }

    refreshTournamentSelect() {
        console.log('Refreshing tournament select');
        const tournamentSelect = document.getElementById('tournamentSelect');
        if (tournamentSelect && this.storage && this.storage.getTournamentDatabase) {
            const tournaments = this.storage.getTournamentDatabase();
            console.log('Tournaments in select:', tournaments);
            tournamentSelect.innerHTML = '<option value="">Select a tournament</option>';
            tournaments.forEach(tournament => {
                tournamentSelect.innerHTML += `<option value="${tournament.id}">${tournament.name} (${tournament.date})</option>`;
            });
            console.log('Tournament select updated:', tournamentSelect.innerHTML);
        }
    }

    refreshTournamentDetails(tournamentId) {
        console.log('Refreshing tournament details for id:', tournamentId);
        const tournamentDetails = document.getElementById('tournamentDetails');
        if (tournamentDetails && this.storage && this.storage.getTournamentDatabase) {
            const tournament = this.storage.getTournamentDatabase().find(t => t.id === tournamentId);
            if (tournament) {
                tournamentDetails.innerHTML = `
                    <h3>${tournament.name}</h3>
                    <p>Date: ${tournament.date}</p>
                    <p>Max Teams: ${tournament.maxTeams}</p>
                    <p>Stacks per Team: ${tournament.stacksPerTeam}</p>
                    <p>Location: ${tournament.location}</p>
                    <p>Start Time: ${tournament.startTime}</p>
                    <p>Type: ${tournament.type}</p>
                    <p>Max Tables: ${tournament.maxTables}</p>
                    <p>Stack Size: ${tournament.stackSize}</p>
                    <p>Status: ${tournament.status}</p>
                    <p>Organizer: ${tournament.organizer}</p>
                    <p>Max Seats per Table: ${tournament.maxSeatsPerTable}</p>
                    <p>Allocation Mode: ${tournament.allocationMode}</p>
                `;
            } else {
                tournamentDetails.innerHTML = '';
            }
        }
    }

    refreshCheckInTeams(tournamentId) {
        console.log('Refreshing check-in teams for tournament id:', tournamentId);
        const checkInTeamsList = document.getElementById('checkInTeamsList');
        if (checkInTeamsList && this.storage && this.storage.getTeams && this.storage.getPlayerDatabase) {
            const teams = this.storage.getTeams().filter(team => team.checkedInTournaments.includes(tournamentId));
            const players = this.storage.getPlayerDatabase();
            checkInTeamsList.innerHTML = '';
            teams.forEach(team => {
                const teamPlayers = team.playerIds
                    .map(id => {
                        const player = players.find(p => p.id === id);
                        return player ? `${player.firstName} ${player.lastName}` : 'Unknown';
                    })
                    .join(', ');
                const captain = players.find(p => p.id === team.captainId);
                const captainName = captain ? `${captain.firstName} ${captain.lastName}` : 'Unknown';
                checkInTeamsList.innerHTML += `
                    <li>
                        ${team.name} - Players: ${teamPlayers}, Captain: ${captainName}
                        <button class="check-in-team-btn btn" data-team-id="${team.id}" data-tournament-id="${tournamentId}">
                            ${team.checkedInTournaments.includes(tournamentId) ? 'Check-out' : 'Check-in'}
                        </button>
                    </li>
                `;
            });
            this.setupCheckInTeamListeners(tournamentId);
        }
    }

    setupCheckInTeamListeners(tournamentId) {
        console.log('Setting up check-in team listeners for tournament id:', tournamentId);
        const checkInTeamButtons = document.querySelectorAll('.check-in-team-btn');
        checkInTeamButtons.forEach(button => {
            button.addEventListener('click', () => {
                const teamId = button.dataset.teamId;
                const tournamentId = button.dataset.tournamentId;
                console.log(`Check-in/Check-out team ${teamId} for tournament ${tournamentId}`);
                this.toggleTeamCheckIn(teamId, tournamentId);
            });
        });
    }

    toggleTeamCheckIn(teamId, tournamentId) {
        console.log(`Toggling check-in for team ${teamId} in tournament ${tournamentId}`);
        if (this.storage && this.storage.getTeams) {
            const teams = this.storage.getTeams();
            const team = teams.find(t => t.id === teamId);
            if (team) {
                if (team.checkedInTournaments.includes(tournamentId)) {
                    team.checkedInTournaments = team.checkedInTournaments.filter(id => id !== tournamentId);
                } else {
                    team.checkedInTournaments.push(tournamentId);
                }
                this.storage.updateTeam(teamId, team);
                this.refreshCheckInTeams(tournamentId);
            }
        }
    }

    openEditTournamentModal() {
        console.log('Opening edit tournament modal');
        const tournamentSelect = document.getElementById('tournamentSelect');
        if (tournamentSelect && this.storage && this.storage.getTournamentDatabase) {
            const tournamentId = tournamentSelect.value;
            const tournament = this.storage.getTournamentDatabase().find(t => t.id === tournamentId);
            if (tournament) {
                document.getElementById('editTournamentName').value = tournament.name;
                document.getElementById('editTournamentDate').value = tournament.date;
                document.getElementById('editTournamentMaxTeams').value = tournament.maxTeams;
                document.getElementById('editTournamentStacksPerTeam').value = tournament.stacksPerTeam;
                document.getElementById('editTournamentLocation').value = tournament.location;
                document.getElementById('editTournamentStartTime').value = tournament.startTime;
                document.getElementById('editTournamentType').value = tournament.type;
                document.getElementById('editTournamentMaxTables').value = tournament.maxTables;
                document.getElementById('editTournamentStackSize').value = tournament.stackSize;
                document.getElementById('editTournamentStatus').value = tournament.status;
                document.getElementById('editTournamentOrganizer').value = tournament.organizer;
                document.getElementById('editTournamentMaxSeatsPerTable').value = tournament.maxSeatsPerTable;
                document.getElementById('editTournamentAllocationMode').value = tournament.allocationMode;
                modalUtils.showModal('editTournamentModal');
            }
        }
    }

    handleCreateTournament() {
        console.log('Handling create tournament');
        const tournament = {
            id: crypto.randomUUID(),
            name: document.getElementById('tournamentName').value,
            date: document.getElementById('tournamentDate').value,
            maxTeams: parseInt(document.getElementById('tournamentMaxTeams').value) || 0,
            stacksPerTeam: parseInt(document.getElementById('tournamentStacksPerTeam').value) || 0,
            location: document.getElementById('tournamentLocation').value,
            startTime: document.getElementById('tournamentStartTime').value,
            type: document.getElementById('tournamentType').value,
            maxTables: parseInt(document.getElementById('tournamentMaxTables').value) || 0,
            stackSize: parseInt(document.getElementById('tournamentStackSize').value) || 0,
            status: document.getElementById('tournamentStatus').value,
            organizer: document.getElementById('tournamentOrganizer').value,
            maxSeatsPerTable: parseInt(document.getElementById('tournamentMaxSeatsPerTable').value) || 9,
            allocationMode: document.getElementById('tournamentAllocationMode').value
        };
        if (this.storage && this.storage.addTournament) {
            this.storage.addTournament(tournament);
            this.refreshTournamentSelect();
            modalUtils.hideModal('createTournamentModal');
        }
    }

    handleEditTournament() {
        console.log('Handling edit tournament');
        const tournamentSelect = document.getElementById('tournamentSelect');
        if (tournamentSelect && this.storage && this.storage.updateTournament) {
            const tournamentId = tournamentSelect.value;
            const tournament = {
                id: tournamentId,
                name: document.getElementById('editTournamentName').value,
                date: document.getElementById('editTournamentDate').value,
                maxTeams: parseInt(document.getElementById('editTournamentMaxTeams').value) || 0,
                stacksPerTeam: parseInt(document.getElementById('editTournamentStacksPerTeam').value) || 0,
                location: document.getElementById('editTournamentLocation').value,
                startTime: document.getElementById('editTournamentStartTime').value,
                type: document.getElementById('editTournamentType').value,
                maxTables: parseInt(document.getElementById('editTournamentMaxTables').value) || 0,
                stackSize: parseInt(document.getElementById('editTournamentStackSize').value) || 0,
                status: document.getElementById('editTournamentStatus').value,
                organizer: document.getElementById('editTournamentOrganizer').value,
                maxSeatsPerTable: parseInt(document.getElementById('editTournamentMaxSeatsPerTable').value) || 9,
                allocationMode: document.getElementById('editTournamentAllocationMode').value
            };
            this.storage.updateTournament(tournamentId, tournament);
            this.refreshTournamentSelect();
            this.refreshTournamentDetails(tournamentId);
            modalUtils.hideModal('editTournamentModal');
        }
    }

    handleSaveAsTournament() {
        console.log('Handling save as tournament');
        const tournament = {
            id: crypto.randomUUID(),
            name: document.getElementById('editTournamentName').value,
            date: document.getElementById('editTournamentDate').value,
            maxTeams: parseInt(document.getElementById('editTournamentMaxTeams').value) || 0,
            stacksPerTeam: parseInt(document.getElementById('editTournamentStacksPerTeam').value) || 0,
            location: document.getElementById('editTournamentLocation').value,
            startTime: document.getElementById('editTournamentStartTime').value,
            type: document.getElementById('editTournamentType').value,
            maxTables: parseInt(document.getElementById('editTournamentMaxTables').value) || 0,
            stackSize: parseInt(document.getElementById('editTournamentStackSize').value) || 0,
            status: document.getElementById('editTournamentStatus').value,
            organizer: document.getElementById('editTournamentOrganizer').value,
            maxSeatsPerTable: parseInt(document.getElementById('editTournamentMaxSeatsPerTable').value) || 9,
            allocationMode: document.getElementById('editTournamentAllocationMode').value
        };
        if (this.storage && this.storage.addTournament) {
            this.storage.addTournament(tournament);
            this.refreshTournamentSelect();
            modalUtils.hideModal('editTournamentModal');
        }
    }

    deleteTournament() {
        console.log('Deleting tournament');
        const tournamentSelect = document.getElementById('tournamentSelect');
        if (tournamentSelect && this.storage && this.storage.deleteTournament) {
            const tournamentId = tournamentSelect.value;
            this.storage.deleteTournament(tournamentId);
            this.refreshTournamentSelect();
            this.refreshTournamentDetails('');
            this.refreshCheckInTeams('');
        }
    }

    generateTableDistribution() {
        console.log('Generating table distribution');
        const tournamentSelect = document.getElementById('tournamentSelect');
        if (tournamentSelect && this.storage && this.storage.getTournamentDatabase && this.storage.getTeams && this.storage.addTable) {
            const tournamentId = tournamentSelect.value;
            const tournament = this.storage.getTournamentDatabase().find(t => t.id === tournamentId);
            const teams = this.storage.getTeams().filter(team => team.checkedInTournaments.includes(tournamentId));
            if (tournament && teams.length > 0) {
                const playersPerTeam = tournament.stacksPerTeam;
                const maxSeatsPerTable = tournament.maxSeatsPerTable;
                const maxTables = tournament.maxTables;
                const allocationMode = tournament.allocationMode.toLowerCase();
                const totalPlayers = teams.reduce((sum, team) => sum + playersPerTeam, 0);
                const tablesNeeded = Math.ceil(totalPlayers / maxSeatsPerTable);
                if (tablesNeeded > maxTables) {
                    console.log('Too many players for available tables');
                    return;
                }
                const tableAssignments = [];
                let remainingPlayers = teams.flatMap(team => Array(playersPerTeam).fill(team.id));
                if (allocationMode === 'random') {
                    remainingPlayers = remainingPlayers.sort(() => Math.random() - 0.5);
                }
                for (let i = 0; i < tablesNeeded; i++) {
                    const table = {
                        id: crypto.randomUUID(),
                        tournamentId,
                        teamIds: []
                    };
                    const seatsForTable = Math.min(remainingPlayers.length, maxSeatsPerTable);
                    table.teamIds = remainingPlayers.splice(0, seatsForTable);
                    tableAssignments.push(table);
                }
                tableAssignments.forEach(table => this.storage.addTable(table));
                this.refreshTableDistribution(tournamentId);
            }
        }
    }

    simulateTableDistribution() {
        console.log('Simulating table distribution');
        const numTeams = parseInt(document.getElementById('simulateNumTeams').value) || 0;
        const maxTables = parseInt(document.getElementById('simulateMaxTables').value) || 0;
        const stacksPerTeam = parseInt(document.getElementById('simulateStacksPerTeam').value) || 0;
        const maxSeatsPerTable = parseInt(document.getElementById('simulateMaxSeatsPerTable').value) || 9;
        const allocationMode = document.getElementById('simulateAllocationMode').value.toLowerCase();
        const totalPlayers = numTeams * stacksPerTeam;
        const tablesNeeded = Math.ceil(totalPlayers / maxSeatsPerTable);
        if (tablesNeeded > maxTables) {
            console.log('Too many players for available tables in simulation');
            return;
        }
        const tableAssignments = [];
        let remainingPlayers = Array(numTeams).fill().map((_, i) => `Team ${i + 1}`);
        remainingPlayers = remainingPlayers.flatMap(team => Array(stacksPerTeam).fill(team));
        if (allocationMode === 'random') {
            remainingPlayers = remainingPlayers.sort(() => Math.random() - 0.5);
        }
        for (let i = 0; i < tablesNeeded; i++) {
            const table = {
                id: crypto.randomUUID(),
                teamIds: []
            };
            const seatsForTable = Math.min(remainingPlayers.length, maxSeatsPerTable);
            table.teamIds = remainingPlayers.splice(0, seatsForTable);
            tableAssignments.push(table);
        }
        const tableDistributionList = document.getElementById('tableDistributionList');
        if (tableDistributionList) {
            tableDistributionList.innerHTML = '';
            tableAssignments.forEach(table => {
                tableDistributionList.innerHTML += `
                    <div>
                        <h4>Table ${table.id}</h4>
                        <ul>
                            ${table.teamIds.map(teamId => `<li>${teamId}</li>`).join('')}
                        </ul>
                    </div>
                `;
            });
        }
        modalUtils.hideModal('simulateTableDistributionModal');
    }

    refreshTableDistribution(tournamentId) {
        console.log('Refreshing table distribution for tournament id:', tournamentId);
        const tableDistributionList = document.getElementById('tableDistributionList');
        if (tableDistributionList && this.storage && this.storage.getTableDatabase) {
            const tables = this.storage.getTableDatabase().filter(table => table.tournamentId === tournamentId);
            tableDistributionList.innerHTML = '';
            tables.forEach(table => {
                tableDistributionList.innerHTML += `
                    <div>
                        <h4>Table ${table.id}</h4>
                        <ul>
                            ${table.teamIds.map(teamId => {
                                const team = this.storage.getTeams().find(t => t.id === teamId);
                                return `<li>${team ? team.name : 'Unknown'}</li>`;
                            }).join('')}
                        </ul>
                    </div>
                `;
            });
        }
    }

    toggleTournamentSection(sectionId) {
        console.log(`Toggling tournament section ${sectionId}`);
        const section = document.getElementById(sectionId);
        if (section) {
            const isVisible = section.style.display !== 'none';
            section.style.display = isVisible ? 'none' : 'block';
            const visibility = JSON.parse(localStorage.getItem('tournamentSectionVisibility')) || {};
            visibility[sectionId] = !isVisible;
            localStorage.setItem('tournamentSectionVisibility', JSON.stringify(visibility));
        }
    }

    render() {
        console.log('TournamentCheckIn rendering');
        const tournamentManagementContainer = document.getElementById('tournamentManagementContainer');
        if (tournamentManagementContainer) {
            tournamentManagementContainer.innerHTML = `
                <div>
                    <h2>Tournament Management</h2>
                    <div id="tournamentSelectContainer">
                        <select id="tournamentSelect">
                            <option value="">Select a tournament</option>
                        </select>
                    </div>
                    <div id="tournamentDetails"></div>
                    <button class="create-tournament-open-btn btn">Create Tournament</button>
                    <button class="edit-tournament-open-btn btn">Edit Tournament</button>
                    <button class="delete-tournament-btn btn">Delete Tournament</button>
                    <div id="createTournamentModal" class="modal">
                        <div class="modal-content">
                            ${dropdownUtils.createInput({ id: 'tournamentName', type: 'text', label: 'Tournament Name', placeholder: 'Enter tournament name' })}
                            ${dropdownUtils.createInput({ id: 'tournamentDate', type: 'date', label: 'Date' })}
                            ${dropdownUtils.createInput({ id: 'tournamentMaxTeams', type: 'number', label: 'Max Teams', placeholder: 'Enter max teams' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStacksPerTeam', type: 'number', label: 'Stacks per Team', placeholder: 'Enter stacks per team' })}
                            ${dropdownUtils.createInput({ id: 'tournamentLocation', type: 'text', label: 'Location', placeholder: 'Enter location' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStartTime', type: 'time', label: 'Start Time' })}
                            ${dropdownUtils.createInput({ id: 'tournamentType', type: 'text', label: 'Type', placeholder: 'Enter tournament type' })}
                            ${dropdownUtils.createInput({ id: 'tournamentMaxTables', type: 'number', label: 'Max Tables', placeholder: 'Enter max tables' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStackSize', type: 'number', label: 'Stack Size', placeholder: 'Enter stack size' })}
                            ${dropdownUtils.createInput({ id: 'tournamentStatus', type: 'text', label: 'Status', placeholder: 'Enter status' })}
                            ${dropdownUtils.createInput({ id: 'tournamentOrganizer', type: 'text', label: 'Organizer', placeholder: 'Enter organizer' })}
                            ${dropdownUtils.createInput({ id: 'tournamentMaxSeatsPerTable', type: 'number', label: 'Max Seats per Table', placeholder: 'Enter max seats per table', defaultValue: 9 })}
                            ${dropdownUtils.createDropdown({ id: 'tournamentAllocationMode', options: ['Sequential', 'Random'], label: 'Allocation Mode', defaultValue: 'random' })}
                            <div class="modal-actions">
                                <button class="create-tournament-btn btn">Save</button>
                                <button class="cancel-btn btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                    <div id="editTournamentModal" class="modal">
                        <div class="modal-content">
                            ${dropdownUtils.createInput({ id: 'editTournamentName', type: 'text', label: 'Tournament Name', placeholder: 'Enter tournament name' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentDate', type: 'date', label: 'Date' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentMaxTeams', type: 'number', label: 'Max Teams', placeholder: 'Enter max teams' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStacksPerTeam', type: 'number', label: 'Stacks per Team', placeholder: 'Enter stacks per team' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentLocation', type: 'text', label: 'Location', placeholder: 'Enter location' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStartTime', type: 'time', label: 'Start Time' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentType', type: 'text', label: 'Type', placeholder: 'Enter tournament type' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentMaxTables', type: 'number', label: 'Max Tables', placeholder: 'Enter max tables' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStackSize', type: 'number', label: 'Stack Size', placeholder: 'Enter stack size' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentStatus', type: 'text', label: 'Status', placeholder: 'Enter status' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentOrganizer', type: 'text', label: 'Organizer', placeholder: 'Enter organizer' })}
                            ${dropdownUtils.createInput({ id: 'editTournamentMaxSeatsPerTable', type: 'number', label: 'Max Seats per Table', placeholder: 'Enter max seats per table', defaultValue: 9 })}
                            ${dropdownUtils.createDropdown({ id: 'editTournamentAllocationMode', options: ['Sequential', 'Random'], label: 'Allocation Mode', defaultValue: 'random' })}
                            <div class="modal-actions">
                                <button class="edit-tournament-btn btn">Save</button>
                                <button class="save-as-tournament-btn btn">Save As</button>
                                <button class="cancel-btn btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                    <button class="toggle-tournament-btn btn" data-section="checkInTeamsContainer">
                        Show Check-in Teams
                    </button>
                    <div id="checkInTeamsContainer" style="display: none;">
                        <h3>Check-in Teams</h3>
                        <ul id="checkInTeamsList"></ul>
                    </div>
                    <button class="toggle-tournament-btn btn" data-section="tableDistributionContainer">
                        Show Table Distribution
                    </button>
                    <div id="tableDistributionContainer" style="display: none;">
                        <h3>Table Distribution</h3>
                        <button class="generate-table-distribution-btn btn">Generate Table Distribution</button>
                        <button class="simulate-table-distribution-btn btn">Simulate Table Distribution</button>
                        <div id="simulateTableDistributionModal" class="modal">
                            <div class="modal-content">
                                ${dropdownUtils.createInput({ id: 'simulateNumTeams', type: 'number', label: 'Number of Teams', placeholder: 'Enter number of teams' })}
                                ${dropdownUtils.createInput({ id: 'simulateMaxTables', type: 'number', label: 'Max Tables', placeholder: 'Enter max tables' })}
                                ${dropdownUtils.createInput({ id: 'simulateStacksPerTeam', type: 'number', label: 'Stacks per Team', placeholder: 'Enter stacks per team' })}
                                ${dropdownUtils.createInput({ id: 'simulateMaxSeatsPerTable', type: 'number', label: 'Max Seats per Table', placeholder: 'Enter max seats per table', defaultValue: 9 })}
                                ${dropdownUtils.createDropdown({ id: 'simulateAllocationMode', options: ['Sequential', 'Random'], label: 'Allocation Mode', defaultValue: 'random' })}
                                <div class="modal-actions">
                                    <button class="simulate-table-distribution-btn btn">Simulate</button>
                                    <button class="cancel-btn btn">Cancel</button>
                                </div>
                            </div>
                        </div>
                        <div id="tableDistributionList"></div>
                    </div>
                </div>
            `;
            console.log('TournamentCheckIn content rendered in tournamentManagementContainer:', tournamentManagementContainer.innerHTML);
            this.refreshTournamentSelect();

            // Flytta setupEventListeners till efter rendering
            this.setupEventListeners();
        }
    }
}

export default TournamentCheckIn;